<?php
/**
 * @package local_edugamecloud
 * @author Gerasimenko Sergey (sergey@esynctraining.com)
  */
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_edugamecloud';
$plugin->version  = 2016070600;
$plugin->requires = 2010112400;  // Requires this Moodle version - at least 2.0
$plugin->cron     = 0;
$plugin->release = '1.0 (Build: 2016070600)';
$plugin->maturity = MATURITY_STABLE;
