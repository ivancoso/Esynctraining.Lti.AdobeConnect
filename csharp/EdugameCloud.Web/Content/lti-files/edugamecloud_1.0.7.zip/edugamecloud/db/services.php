<?php

$functions = array(        
        'local_edugamecloud_get_user_record' => array(
                'classname'   => 'local_edugamecloud_external',
                'methodname'  => 'getUserRecord',
                'classpath'   => 'local/edugamecloud/externallib.php',
                'description' => 'return user record',
                'type'        => 'read',
        ),
        'local_edugamecloud_save_external_quiz_report' => array(
                'classname'   => 'local_edugamecloud_external',
                'methodname'  => 'saveExternalQuizReport',
                'classpath'   => 'local/edugamecloud/externallib.php',
                'description' => 'save quiz report',
                'type'        => 'write',
        ),
        'local_edugamecloud_get_total_quiz_list' => array(
                'classname'   => 'local_edugamecloud_external',
                'methodname'  => 'getTotalQuizList',
                'classpath'   => 'local/edugamecloud/externallib.php',
                'description' => 'get total quiz list',
                'type'        => 'read',
        ),
        'local_edugamecloud_get_quiz_by_id' => array(
                'classname'   => 'local_edugamecloud_external',
                'methodname'  => 'getQuizById',
                'classpath'   => 'local/edugamecloud/externallib.php',
                'description' => 'get quiz by id',
                'type'        => 'read',
        ),
        'local_edugamecloud_get_total_survey_list' => array(
                'classname'   => 'local_edugamecloud_external',
                'methodname'  => 'getTotalSurveyList',
                'classpath'   => 'local/edugamecloud/externallib.php',
                'description' => 'get total survey list',
                'type'        => 'read',
        ),
        'local_edugamecloud_get_survey_by_id' => array(
                'classname'   => 'local_edugamecloud_external',
                'methodname'  => 'getSurveyById',
                'classpath'   => 'local/edugamecloud/externallib.php',
                'description' => 'get survey by id',
                'type'        => 'read',
        ),
        'local_edugamecloud_save_external_survey_report' => array(
                'classname'   => 'local_edugamecloud_external',
                'methodname'  => 'saveExternalSurveyReport',
                'classpath'   => 'local/edugamecloud/externallib.php',
                'description' => 'save survey/feedback report',
                'type'        => 'write',
        )
);

$services = array(
        'Edugamecloud service' => array(
                'functions' => array (                        
                        'local_edugamecloud_get_user_record',
                        'local_edugamecloud_save_external_quiz_report',
                        'local_edugamecloud_get_total_quiz_list',
                        'local_edugamecloud_get_quiz_by_id',
                        'local_edugamecloud_get_total_survey_list',
                        'local_edugamecloud_get_survey_by_id',
                        'local_edugamecloud_save_external_survey_report'
                ),
                'restrictedusers' => 0,
                'enabled'=>1,
                'shortname'=>'edugamecloud'
        )
);