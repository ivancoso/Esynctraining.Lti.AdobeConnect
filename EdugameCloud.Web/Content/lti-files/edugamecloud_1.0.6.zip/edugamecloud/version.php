<?php
/**
 * @package local_edugamecloud
 * @author Gerasimenko Sergey (sergey@esynctraining.com)
  */
$plugin->version  = 2014111903;
$plugin->requires = 2010112400;  // Requires this Moodle version - at least 2.0
$plugin->cron     = 0;
$plugin->release = '1.0 (Build: 2014111900)';
$plugin->maturity = MATURITY_STABLE;