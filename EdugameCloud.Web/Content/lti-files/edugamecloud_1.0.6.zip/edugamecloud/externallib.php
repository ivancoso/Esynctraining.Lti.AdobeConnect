<?php
	global $CFG;
	require_once($CFG->dirroot . '/mod/quiz/attemptlib.php');
	require_once($CFG->dirroot . '/mod/quiz/accessmanager.php');
	require_once($CFG->libdir . "/externallib.php");
	require_once "reportlib.php";

	class local_edugamecloud_external extends external_api 
	{
		//-----------------------------------------------------------------------------------------------------------------------------GET USER RECORD
		/**
	     * Returns description of method parameters
	     * @return external_function_parameters
	     */
		public static function getUserRecord_parameters()
		{
			return new external_function_parameters(
				array()
			);
		}


		/**
	     * Returns user record
	     * @return object user 
	     */
	    public static function getUserRecord() {
	    	global $USER;

	    	return (array)$USER;
	    }


		/**
	     * Returns description of method result value
	     * @return external_description
	     */
	    public static function getUserRecord_returns() {
	        return new external_single_structure(
	        	array(
					'id' => new external_value(PARAM_INT),
	        		'username' => new external_value(PARAM_TEXT),
                    'firstname' => new external_value(PARAM_TEXT),
                    'lastname' => new external_value(PARAM_TEXT),
					'email' => new external_value(PARAM_TEXT)
	        	)
        	);
	    }




	    //-----------------------------------------------------------------------------------------------------------------------------SAVE EXTERNAL QUIZ REPORT
	    /**
	    * Returns description of method parameters
	    * @return external_function_parameters
	    */
	    public static function saveExternalQuizReport_parameters()
	    {
	    	return new external_function_parameters(
				array('reportObject' => new external_value(PARAM_RAW, 'JSON string with EGC report object'))
			);
	    }

    	/**
	     * Returns boolean result
	     * @return boolean result
	     */
	    public static function saveExternalQuizReport( $reportObject )
	    {
	    	$reportData = null;
	    	$reportObj = json_decode( $reportObject );

	    	if ( isset( $reportObj[0]))
	    		$reportData = $reportObj[0];

	    	if ( !$reportData )
	    		return false;

	    	$quizId = $reportData->quizId;	    	
	    	$timenow = time();
			
	    	foreach( $reportData->usersResults as $userResult )
	    	{
	    		$userId = $userResult->userId;
	    		$startTime = intval( $userResult->startTime ) - intval( timezone_offset_get( new DateTimeZone( date_default_timezone_get()), new DateTime()));

	    		$quizobj = quiz::create( $quizId, $userId );

	    		$quizobj->preload_questions();
                $quizobj->load_questions();
             	$questions = $quizobj->get_questions();

	    		$quba = question_engine::make_questions_usage_by_activity( 'mod_quiz', $quizobj->get_context());
            	$quba->set_preferred_behaviour( $quizobj->get_quiz()->preferredbehaviour );

            	$prevattempts = quiz_get_user_attempts( $quizId, $userId, 'all', true );
            	$attemptnumber = count( $prevattempts ) + 1;

            	$attempt = quiz_create_attempt( $quizobj, $attemptnumber, false, $startTime, false, $userId );

            	quiz_start_new_attempt( $quizobj, $quba, $attempt, $attemptnumber, $startTime );

            	quiz_attempt_save_started( $quizobj, $quba, $attempt );

            	$attemptobj = quiz_attempt::create( $attempt->id );

        		$tosubmit = array();
				
				foreach( $userResult->answers as $answer )
				{
					$question = get_question_by_id( $answer->questionId, $questions );
					$questionNumber = get_question_number( $answer->questionId, $questions );
					$questionAnswer;
					
					switch( $question->qtype ) 
					{
						case "truefalse":
							 $questionAnswer = array( 'answer' => reset( $answer->answers ) == 'true' );
						break;
						case "multichoice":
							if ( $question->options->single )
								$questionAnswer = array( 'answer' => reset( $answer->answers ));
							else
								$questionAnswer = perform_answer_for_multichoice_question( $answer->answers );								
						break;
						case "numerical":
							$questionAnswer = array( 'answer' => reset( $answer->answers ));
						break;
						case "essay":
							$questionAnswer = array( 'answer' => reset( $answer->answers ));
						break;
						case "shortanswer":
							$questionAnswer = array( 'answer' => reset( $answer->answers ));
						break;
						case "multianswer":
							$attemptobj->get_question_attempt( $questionNumber )->process_action( perform_answer_for_multianswer_question( $answer->answers ), $timenow );
						break;
						case "match":							
							$questionAnswer = perform_answer_for_matching_question($answer->answers);
						break;
						case "calculated":
							// $attemptobj->get_question_attempt( $questionNumber )->get_variant(); //get_correct_response
							$questionAnswer = array( 'answer' => reset( $answer->answers ));
						break;
						case "calculatedmulti":
							if ( $question->options->single )
								$questionAnswer = array( 'answer' => reset( $answer->answers ));
							else
								$questionAnswer = perform_answer_for_multichoice_question( $answer->answers );
						break;
						case "calculatedsimple":
							$questionAnswer = array( 'answer' => reset( $answer->answers ));
						break;
					}

					$tosubmit[ $questionNumber ] = $questionAnswer;
					//return json_encode($tosubmit);
			 	}
				
            	$attemptobj->process_submitted_actions( $timenow, false, $tosubmit );

	            $attemptobj = quiz_attempt::create( $attempt->id );
	            $attemptobj->process_finish( $timenow, false );
	    	}


	    	return true;
	    }

    	/**
	     * Returns description of method result value
	     * @return external_description
	     */
    	public static function saveExternalQuizReport_returns()
    	{
			return new external_value(PARAM_TEXT, 'Operation result');
    	}





    	//-----------------------------------------------------------------------------------------------------------------------------GET TOTAL QUIZ LIST
    	/**
	    * Returns description of method parameters
	    * @return external_function_parameters
	    */
	    public static function getTotalQuizList_parameters()
	    {
	    	return new external_function_parameters(
			 	array(
                	'course' => new external_value(PARAM_TEXT, 'Course Id')
            	)
			);
	    }

    	/**
	     * Returns boolean result
	     * @return boolean result
	     */
	    public static function getTotalQuizList( $course = 0 )
	    {
			global $DB, $USER;

	    	$result = array('quizzes' => array(), 'courses' => array());

	    	$conditions = $course ? array( 'course' => $course ) : null;

    		$quizzes = $DB->get_recordset('quiz', $conditions, '', 'id, name, intro, course, timemodified');            
            foreach ($quizzes as $quiz)  
            {
            	$quizArr = (array)$quiz;
            	$quizArr['timemodified'] = get_quiz_last_modified_date( $quizArr['id'], $USER->id, $quizArr['timemodified'] ) + intval( timezone_offset_get( new DateTimeZone( date_default_timezone_get()), new DateTime()));            	
            	
				$quizobj = quiz::create( $quiz->id, $USER->id );
            	if ($quizobj->has_questions()) {
	                $quizobj->preload_questions();
	                $quizobj->load_questions();
	             	$quizArr['questionCount'] = count( $quizobj->get_questions());

	             	$result['quizzes'][] = $quizArr;
	            } 	            
            }
            	
        	        	
            $courses = $DB->get_recordset('course', null, '', 'id, fullname, summary');
            foreach ($courses as $course)
                $result['courses'][] = (array)$course;
                		
        	return $result;
	    }

    	/**
	     * Returns description of method result value
	     * @return external_description
	     */
    	public static function getTotalQuizList_returns()
    	{
			return new external_single_structure(
				array(
					'quizzes' => new external_multiple_structure(
						new external_single_structure(
			                array(
		                    	'id' => new external_value(PARAM_TEXT, 'quiz record id'),
		                    	'course' => new external_value(PARAM_TEXT, 'course id'),
		                    	'name' => new external_value(PARAM_TEXT, 'quiz name'),
		                    	'intro' => new external_value(PARAM_RAW, 'quiz description', VALUE_OPTIONAL),
		                    	'timemodified' => new external_value(PARAM_TEXT, 'last modofied date'),
		                    	'questionCount' => new external_value(PARAM_RAW, 'quiz question count', VALUE_OPTIONAL),
		                	)	
		            	)
					),
					'courses' => new external_multiple_structure(
						new external_single_structure(
			                array(
		                    	'id' => new external_value(PARAM_TEXT, 'course record id'),
		                    	'fullname' => new external_value(PARAM_TEXT, 'course name'),
		                    	'summary' => new external_value(PARAM_RAW, 'course description', VALUE_OPTIONAL),
		                	)	
		            	)
					)				
				)
			);
    	}





    	//-----------------------------------------------------------------------------------------------------------------------------GET QUIZ BY ID
    	/**
	    * Returns description of method parameters
	    * @return external_function_parameters
	    */
    	public static function getQuizById_parameters() 
    	{
        	return new external_function_parameters(
                array(
                	'quizId' => new external_value(PARAM_TEXT, 'Quiz Id')
            	)
	        );
	    }

	    /**
	     * Returns quiz record
	     * @return object quiz 
	     */
	    public static function getQuizById($quizId)
	    {
	    	global $USER, $DB;

	    	if (!$quizId)
	    		$quizId = 1;

			$quizSource = (array)quiz_access_manager::load_quiz_and_settings($quizId);
			$questionArr = array();

			$quiz = quiz::create($quizId, $USER->id);
            if ($quiz->has_questions()) {
                $quiz->preload_questions();
                $quiz->load_questions();
             	$questionArr = $quiz->get_questions();             	
            } 

			foreach( $questionArr as $question )
				if ( $question->qtype == 'calculated' || $question->qtype ==  'calculatedsimple' || $question->qtype == 'calculatedmulti' )
					$question->datasets = get_dataset_for_calculated_question( $question->id );

    		$quizSource[questions] = $questionArr;
            $quizSource[course] = (array)$DB->get_record( 'course', array( 'id' => $quizSource[course] ), 'id, fullname, summary', MUST_EXIST );

    		return $quizSource;
	    }

	    /**
	     * Returns description of method result value
	     * @return external_description
	     */
    	public static function getQuizById_returns()
    	{
			return new external_single_structure(
                array(
                	'id' => new external_value(PARAM_TEXT, 'quiz id'),
                	'name' => new external_value(PARAM_TEXT, 'quiz name'),                	
                	'intro' => new external_value(PARAM_RAW, 'quiz description'),
                	'timelimit' => new external_value(PARAM_RAW, 'quiz time limit in seconds'),
                	'course' => new external_single_structure(
		                array(
	                    	'id' => new external_value(PARAM_TEXT, 'course record id'),
	                    	'fullname' => new external_value(PARAM_TEXT, 'course name'),
	                    	'summary' => new external_value(PARAM_RAW, 'course description', VALUE_OPTIONAL),
	                	),
		            	'course object', VALUE_OPTIONAL
					),
                	'questions' => new external_multiple_structure(
                		new external_single_structure(
			                array(	
			                	'id' => new external_value(PARAM_TEXT, 'question id'),	                    	
		                    	'name' => new external_value(PARAM_TEXT, 'question name'),		
		                    	'questiontext' => new external_value(PARAM_RAW, 'question description'),	
		                    	'qtype'	=>  new external_value(PARAM_TEXT, 'question type'),	
		                    	'datasets' => new external_multiple_structure(
									new external_single_structure(
						                array(
											'id' => new external_value(PARAM_TEXT, 'dataset id'),
											'name' => new external_value(PARAM_TEXT, 'dataset name'),
											'minimum' => new external_value(PARAM_TEXT),
											'maximum' => new external_value(PARAM_TEXT),
											'items' => new external_multiple_structure(
												new external_single_structure(
						                			array(
		                								'itemnumber' => new external_value(PARAM_TEXT),
		                								'value' => new external_value(PARAM_TEXT),
					                				)
				                				),
				                				'dataset items', VALUE_OPTIONAL
				                			),				                			
					                	)
				                	),
				                	'datasets array', VALUE_OPTIONAL
	                    		),
		                    	'options' => new external_single_structure(
		                    		 array(	
		                    		 	'single' => new external_value(PARAM_TEXT, 'is single answer for multichoice question', VALUE_OPTIONAL),
		                    			'answers' =>  new external_multiple_structure(
		                    				new external_single_structure(
		                    					array(	
		                    						'id' => new external_value(PARAM_TEXT, 'answer id'),	                    	
		                    						'answer' =>  new external_value(PARAM_RAW, 'answer text'),	
			                    					'fraction' => new external_value(PARAM_TEXT, 'id of true answer', VALUE_OPTIONAL),	
			                    					'feedback' => new external_value(PARAM_RAW, 'answer feedback', VALUE_OPTIONAL),	
			                    					'tolerance' => new external_value(PARAM_TEXT, 'answer tolerance', VALUE_OPTIONAL),	
	                    						)	
	                    					),
	                    					'list of answers', VALUE_OPTIONAL
                    					),	                    		 
			                    		'questions' => new external_multiple_structure(
					                		new external_single_structure(
								                array(	
								                	'id' => new external_value(PARAM_TEXT, 'question id'),	                    	
							                    	'name' => new external_value(PARAM_TEXT, 'question name'),		
							                    	'questiontext' => new external_value(PARAM_RAW, 'question description'),	
							                    	'qtype'	=>  new external_value(PARAM_TEXT, 'question type'),	
							                    	'options' => new external_single_structure(
							                    		 array(	
							                    			'answers' =>  new external_multiple_structure(
							                    				new external_single_structure(
							                    					array(	
							                    						'id' => new external_value(PARAM_TEXT, 'answer id'),	                    	
							                    						'answer' =>  new external_value(PARAM_RAW, 'answer text'),	
								                    					'fraction' => new external_value(PARAM_TEXT, 'id of true answer', VALUE_OPTIONAL),
								                    					'tolerance' => new external_value(PARAM_TEXT, 'answer tolerance', VALUE_OPTIONAL),	
								                    					'feedback' => new external_value(PARAM_RAW, 'answer feedback', VALUE_OPTIONAL),				                    		
						                    						)	
						                    					),
						                    					'list of answers', VALUE_OPTIONAL
					                    					),
						                    		 	)
						                    		)
						                    		
							                	)	
							            	),
											'additional questions', VALUE_OPTIONAL
					            		),
										'subquestions' => new external_multiple_structure(
					                		new external_single_structure(
								                array(	
								                	'id' => new external_value(PARAM_TEXT, 'question id'),	                    								                    	
							                    	'questiontext' => new external_value(PARAM_RAW, 'matching question text'),	
							                    	'answertext' => new external_value(PARAM_RAW, 'matching answer text'),	
							                	)	
							            	),
											'additional subquestions', VALUE_OPTIONAL
					            		)
									),
									'questions list', VALUE_OPTIONAL
	                    		)	                    		
		                	)	
		            	)
            		)
            	)
			);
    	}



    	
    	//-----------------------------------------------------------------------------------------------------------------------------GET TOTAL SURVEY (FEEDBACK) LIST
    	/**
	    * Returns description of method parameters
	    * @return external_function_parameters
	    */
	    public static function getTotalSurveyList_parameters()
	    {
	    	return new external_function_parameters(
			 	array(
                	'course' => new external_value(PARAM_TEXT, 'Course Id')
            	)
			);
	    }

    	/**
	     * Returns boolean result
	     * @return boolean result
	     */
	    public static function getTotalSurveyList( $course = 0 )
	    {
			global $DB, $USER;

	    	$result = array('surveys' => array(), 'courses' => array());

	    	$conditions = $course ? array( 'course' => $course ) : null;

    		$surveys = $DB->get_recordset('feedback', $conditions, '', 'id, name, intro, course, timemodified');            
            foreach ($surveys as $survey)  
            {
            	$surveyArr = (array)$survey;
            	// $quizArr['timemodified'] = get_quiz_last_modified_date( $quizArr['id'], $USER->id, $quizArr['timemodified'] );
            	$result['surveys'][] = $surveyArr;
            }
            	
        	        	
            $courses = $DB->get_recordset('course', null, '', 'id, fullname, summary');
            foreach ($courses as $course)
                $result['courses'][] = (array)$course;
                		
        	return $result;
	    }

    	/**
	     * Returns description of method result value
	     * @return external_description
	     */
    	public static function getTotalSurveyList_returns()
    	{
			return new external_single_structure(
				array(
					'surveys' => new external_multiple_structure(
						new external_single_structure(
			                array(
		                    	'id' => new external_value(PARAM_TEXT, 'survey record id'),
		                    	'course' => new external_value(PARAM_TEXT, 'course id'),
		                    	'name' => new external_value(PARAM_TEXT, 'survey name'),
		                    	'intro' => new external_value(PARAM_RAW, 'survey description', VALUE_OPTIONAL),
		                    	'timemodified' => new external_value(PARAM_TEXT, 'last modofied date'),
		                	)	
		            	)
					),
					'courses' => new external_multiple_structure(
						new external_single_structure(
			                array(
		                    	'id' => new external_value(PARAM_TEXT, 'course record id'),
		                    	'fullname' => new external_value(PARAM_TEXT, 'course name'),
		                    	'summary' => new external_value(PARAM_RAW, 'course description', VALUE_OPTIONAL),
		                	)	
		            	)
					)				
				)
			);
    	}





    	//-----------------------------------------------------------------------------------------------------------------------------GET SURVEY (FEEDBACK) BY ID
    	/**
	    * Returns description of method parameters
	    * @return external_function_parameters
	    */
	    public static function getSurveyById_parameters()
	    {
	    	return new external_function_parameters(
			 	array(
                	'surveyId' => new external_value(PARAM_TEXT, 'Survey Id')
            	)
			);
	    }

    	/**
	     * Returns boolean result
	     * @return boolean result
	     */
	    public static function getSurveyById( $surveyId )
	    {
			global $DB;

    		$survey = (array)$DB->get_record( 'feedback', array( 'id' => $surveyId ), '*', MUST_EXIST );
			
			$survey[course] = (array)$DB->get_record( 'course', array( 'id' => $survey[course] ), 'id, fullname, summary', MUST_EXIST );

			$items = $DB->get_records( 'feedback_item', array( 'feedback' => $surveyId ), 'position' );

			foreach ( $items as $item )         
			    $survey['questions'][] = (array)$item;
                		
        	return $survey;
	    }

    	/**
	     * Returns description of method result value
	     * @return external_description
	     */
    	public static function getSurveyById_returns()
    	{
			return new external_single_structure(
                array(
                	'id' => new external_value(PARAM_TEXT, 'survey record id'),
                	'course' => new external_single_structure(
		                array(
	                    	'id' => new external_value(PARAM_TEXT, 'course record id'),
	                    	'fullname' => new external_value(PARAM_TEXT, 'course name'),
	                    	'summary' => new external_value(PARAM_RAW, 'course description', VALUE_OPTIONAL),
	                	),
		            	'course object', VALUE_OPTIONAL
					),
                	'name' => new external_value(PARAM_TEXT, 'survey name'),
                	'intro' => new external_value(PARAM_RAW, 'survey description', VALUE_OPTIONAL),
                	'timemodified' => new external_value(PARAM_TEXT, 'last modofied date'),
                	'questions' => new external_multiple_structure(
						new external_single_structure(
			                array(
		                    	'id' => new external_value(PARAM_TEXT, 'question id'),
		                    	'name' => new external_value(PARAM_TEXT, 'question name'),
		                    	'typ' => new external_value(PARAM_TEXT, 'question type'),
								'required' => new external_value(PARAM_RAW, 'if required'),
		                    	'presentation' => new external_value(PARAM_RAW, 'question body'),
		                	)	
		            	)
					)
            	)
			);
    	}




		
		//-----------------------------------------------------------------------------------------------------------------------------SAVE SURVEY (FEEDBACK) REPORT
		/**
	    * Returns description of method parameters
	    * @return external_function_parameters
	    */
	    public static function saveExternalSurveyReport_parameters()
	    {
	    	return new external_function_parameters(
				array('reportObject' => new external_value(PARAM_RAW, 'JSON string with EGC report object'))
			);
	    }

	    /**
	     * Returns boolean result
	     * @return boolean result
	     */
	    public static function saveExternalSurveyReport( $reportObject )
	    {
	    	global $DB;

	    	$reportData = null;
	    	$reportObj = json_decode( $reportObject );

	    	if ( isset( $reportObj[0]))
	    		$reportData = $reportObj[0];

	    	if ( !$reportData )
	    		return false;

	    	$surveyId = $reportData->surveyId;	    	
	    	$courseId = $reportData->courseId;
	    	$timenow = time();
			
			$survey = (array)$DB->get_record( 'feedback', array( 'id' => $surveyId ), '*', MUST_EXIST );

	    	foreach( $reportData->usersResults as $userResult )
	    	{
	    		$userId = $userResult->userId;	    		

	    		$response = new stdClass();
			    $response->feedback           = $surveyId;
			    $response->userid             = $userId;
			    $response->guestid            = false;
			    $response->timemodified       = $timenow;
			    $response->anonymous_response = $survey['anonymous'];
			    $response->random_response    = 0;

				$responseId = $DB->insert_record( 'feedback_completed', $response );
    			$response = $DB->get_record( 'feedback_completed', array( 'id' => $responseId ));

    			foreach( $userResult->answers as $answer )
				{
					$question = $DB->get_record( 'feedback_item', array( 'id' => $answer->questionId ));
   
			        $value = new stdClass();
			        $value->item = $question->id;
			        $value->completed = $response->id;
			        $value->course_id = $courseId;
			        $value->value = $answer->answer;
			        $DB->insert_record('feedback_value', $value);
				}

    			$tracking = new stdClass();
			    $tracking->userid = $userId;
			    $tracking->feedback = $surveyId;
			    $tracking->completed = $responseId;
			    $DB->insert_record( 'feedback_tracking', $tracking );
	    	}

	    	return true;
	    }

	    /**
	     * Returns description of method result value
	     * @return external_description
	     */
    	public static function saveExternalSurveyReport_returns()
    	{
			return new external_value(PARAM_TEXT, 'Operation result');
    	}
	}
?>