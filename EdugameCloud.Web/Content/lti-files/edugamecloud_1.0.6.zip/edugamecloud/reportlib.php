<?php 

function get_question_by_id( $id, $questionArr )
{
	foreach( $questionArr as $question )
		if ( $question->id == $id )
			return $question;

	return null;
}

function get_question_number( $id, $questionArr )
{
	$i = 1;
	$isFound = false;

	foreach( $questionArr as $question )
	{
		if ( $question->id == $id )
		{
			$isFound = true;
			break;
		}
		
		$i++;
	}
		

	return $isFound ? $i : 0;
}

function perform_answer_for_multichoice_question( $qArr )
{
	$result = array();
	
	for ( $i = 0; $i < count( $qArr ); $i++ )
		$result[$qArr[ $i ]] = '1';

	return $result;
}

function perform_answer_for_multianswer_question( $qArr )
{
	$result = array();
	
	for ( $i = 0; $i < count( $qArr ); $i++ )
		$result[ 'sub' . ( $i + 1 ) . '_answer' ] = $qArr[ $i ];

	return $result;
}

function perform_answer_for_matching_question( $qArr )
{
	$result = array();
	
	for ( $i = 0; $i < count( $qArr ); $i++ )
		$result = array_merge($result, (array)$qArr[ $i ]);

	return $result;
}

function get_quiz_last_modified_date( $quizId, $userId, $default )
{
	$quiz = quiz::create( $quizId, $userId );

	$date = $default;

	if ( $quiz->has_questions()) {
	    $quiz->preload_questions();
	    $quiz->load_questions();	    

	    foreach ( $quiz->get_questions() as $question )
	    	if ( $question->timemodified > $date )
	    		$date = $question->timemodified;
    }

	return $date;	
}

function get_dataset_for_calculated_question( $questionId )
{
	global $CFG, $DB;

	$datasetdefs = array();
        
    $sql = "SELECT i.*
              FROM {question_datasets} d, {question_dataset_definitions} i
             WHERE d.question = ? AND d.datasetdefinition = i.id";
    if ($records = $DB->get_records_sql($sql, array( $questionId ))) {
        foreach ($records as $r) {
            $def = $r;
            if ($def->category == '0') {
                $def->status = 'private';
            } else {
                $def->status = 'shared';
            }
            $def->type = 'calculated';
            list($distribution, $min, $max, $dec) = explode(':', $def->options, 4);
            $def->distribution = $distribution;
            $def->minimum = $min;
            $def->maximum = $max;
            $def->decimals = $dec;
            if ($def->itemcount > 0) {
                // Get the datasetitems.
                $def->items = array();
                if ($items = get_database_dataset_items($def->id)) {
                    $n = 0;
                    foreach ($items as $ii) {
                        $n++;
                        $def->items[$n] = new stdClass();
                        $def->items[$n]->itemnumber = $ii->itemnumber;
                        $def->items[$n]->value = $ii->value;
                    }
                    $def->number_of_items = $n;
                }
            }
            $datasetdefs["1-$r->category-$r->name"] = $def;
        }
    }

    return $datasetdefs;
}

function get_database_dataset_items($definition) {
    global $CFG, $DB;
    $databasedataitems = $DB->get_records_sql(// Use number as key!!
        " SELECT id , itemnumber, definition,  value
        FROM {question_dataset_items}
        WHERE definition = $definition order by id DESC ", array($definition));
    $dataitems = Array();
    foreach ($databasedataitems as $id => $dataitem) {
        if (!isset($dataitems[$dataitem->itemnumber])) {
            $dataitems[$dataitem->itemnumber] = $dataitem;
        }
    }
    ksort($dataitems);
    return $dataitems;
}
