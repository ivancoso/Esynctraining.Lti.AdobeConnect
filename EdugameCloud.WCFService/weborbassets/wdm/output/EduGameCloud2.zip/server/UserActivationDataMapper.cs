
        namespace EduGameCloud2
        {
        public class UserActivationDataMapper :_UserActivationDataMapper
        {
        public UserActivationDataMapper()
        {}
        public UserActivationDataMapper(EduGameCloud2Db database):base(database)
        {}
        }
        }
      