
          namespace EduGameCloud2
          {
          public partial class EduGameCloud2Db
          {

          }
          }
        