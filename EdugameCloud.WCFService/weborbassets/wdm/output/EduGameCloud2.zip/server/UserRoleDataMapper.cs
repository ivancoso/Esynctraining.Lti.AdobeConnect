
        namespace EduGameCloud2
        {
        public class UserRoleDataMapper :_UserRoleDataMapper
        {
        public UserRoleDataMapper()
        {}
        public UserRoleDataMapper(EduGameCloud2Db database):base(database)
        {}
        }
        }
      