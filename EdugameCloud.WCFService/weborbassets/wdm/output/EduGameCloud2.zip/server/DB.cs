
          namespace EduGameCloud2
          {
          using System;
          
    using System.Data;
    using System.Collections;
    using System.Collections.Generic;
    using Weborb.Data.Management;

    
    using System.Data.SqlClient;
  
    public partial class EduGameCloud2Db:TDatabase<SqlConnection,SqlTransaction,SqlCommand>
    {
      public EduGameCloud2Db()
      {
        InitConnectionString("EduGameCloud2");
      }

    

        public User create(User user)
        {
          UserDataMapper dataMapper = new UserDataMapper(this);
          
          return dataMapper.create(user);
        }

        public User update(User user)
        {
          UserDataMapper dataMapper = new UserDataMapper(this);

          return dataMapper.update(user);
        }

        public User remove(User user, bool cascade)
        {
          UserDataMapper dataMapper = new UserDataMapper(this);

          return dataMapper.remove(user, cascade);
        }
    

        public UserActivation create(UserActivation userActivation)
        {
          UserActivationDataMapper dataMapper = new UserActivationDataMapper(this);
          
          return dataMapper.create(userActivation);
        }

        public UserActivation update(UserActivation userActivation)
        {
          UserActivationDataMapper dataMapper = new UserActivationDataMapper(this);

          return dataMapper.update(userActivation);
        }

        public UserActivation remove(UserActivation userActivation, bool cascade)
        {
          UserActivationDataMapper dataMapper = new UserActivationDataMapper(this);

          return dataMapper.remove(userActivation, cascade);
        }
    

        public UserRole create(UserRole userRole)
        {
          UserRoleDataMapper dataMapper = new UserRoleDataMapper(this);
          
          return dataMapper.create(userRole);
        }

        public UserRole update(UserRole userRole)
        {
          UserRoleDataMapper dataMapper = new UserRoleDataMapper(this);

          return dataMapper.update(userRole);
        }

        public UserRole remove(UserRole userRole, bool cascade)
        {
          UserRoleDataMapper dataMapper = new UserRoleDataMapper(this);

          return dataMapper.remove(userRole, cascade);
        }
    
        public DataSet Sp_alterdiagram(
        String 
            Diagramname,int 
            Owner_id,int 
            Version,byte[] 
            Definition)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[sp_alterdiagram]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@diagramname", 
                        Diagramname);
                    
                      sqlCommand.Parameters.AddWithValue("@owner_id", 
                        Owner_id);
                    
                      sqlCommand.Parameters.AddWithValue("@version", 
                        Version);
                    
                      sqlCommand.Parameters.AddWithValue("@definition", 
                        Definition);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet Sp_creatediagram(
        String 
            Diagramname,int 
            Owner_id,int 
            Version,byte[] 
            Definition)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[sp_creatediagram]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@diagramname", 
                        Diagramname);
                    
                      sqlCommand.Parameters.AddWithValue("@owner_id", 
                        Owner_id);
                    
                      sqlCommand.Parameters.AddWithValue("@version", 
                        Version);
                    
                      sqlCommand.Parameters.AddWithValue("@definition", 
                        Definition);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet Sp_dropdiagram(
        String 
            Diagramname,int 
            Owner_id)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[sp_dropdiagram]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@diagramname", 
                        Diagramname);
                    
                      sqlCommand.Parameters.AddWithValue("@owner_id", 
                        Owner_id);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet Sp_helpdiagramdefinition(
        String 
            Diagramname,int 
            Owner_id)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[sp_helpdiagramdefinition]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@diagramname", 
                        Diagramname);
                    
                      sqlCommand.Parameters.AddWithValue("@owner_id", 
                        Owner_id);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet Sp_helpdiagrams(
        String 
            Diagramname,int 
            Owner_id)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[sp_helpdiagrams]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@diagramname", 
                        Diagramname);
                    
                      sqlCommand.Parameters.AddWithValue("@owner_id", 
                        Owner_id);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet Sp_renamediagram(
        String 
            Diagramname,int 
            Owner_id,String 
            New_diagramname)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[sp_renamediagram]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@diagramname", 
                        Diagramname);
                    
                      sqlCommand.Parameters.AddWithValue("@owner_id", 
                        Owner_id);
                    
                      sqlCommand.Parameters.AddWithValue("@new_diagramname", 
                        New_diagramname);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet Sp_upgraddiagrams(
        )
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[sp_upgraddiagrams]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
    }
  
          }
        