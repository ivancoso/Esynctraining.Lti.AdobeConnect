
      namespace EduGameCloud2
      {
      using System;
      
    using System.Data;
    using System.Collections;
    using System.Collections.Generic;
    using Weborb.Data.Management;

    
    using System.Data.SqlClient;
  
    
    public partial class User: DomainObject
    {
    
      protected int _userId;
    
      protected int _companyId;
    
      protected int _languageId;
    
      protected int _timeZoneId;
    
      protected int _userRoleId;
    
      protected String _firstName;
    
      protected String _lastName;
    
      protected String _password;
    
      protected String _email;
    
      protected int? _createdBy;
    
      protected int? _modifiedBy;
    
      protected DateTime _dateCreated;
    
      protected DateTime _dateModified;
    
      protected bool? _isActive;
    

      // parent tables
      protected UserRole _relatedUserRole;
    

    public User(){}

    public User(
    int 
            userId,int 
            companyId,int 
            languageId,int 
            timeZoneId,int 
            userRoleId,String 
            firstName,String 
            lastName,String 
            password,String 
            email,int 
            createdBy,int 
            modifiedBy,DateTime 
            dateCreated,DateTime 
            dateModified,bool 
            isActive
    )
    {
    
      this.UserId = userId;
    
      this.CompanyId = companyId;
    
      this.LanguageId = languageId;
    
      this.TimeZoneId = timeZoneId;
    
      this.UserRoleId = userRoleId;
    
      this.FirstName = firstName;
    
      this.LastName = lastName;
    
      this.Password = password;
    
      this.Email = email;
    
      this.CreatedBy = createdBy;
    
      this.ModifiedBy = modifiedBy;
    
      this.DateCreated = dateCreated;
    
      this.DateModified = dateModified;
    
      this.IsActive = isActive;
    
    }

    public override bool contains(Hashtable fields)
    {
      int matchCount = 0;
      
        if(fields.ContainsKey("UserId"))
        {
          
              if(!fields["UserId"].Equals(this.UserId))
            
            return false;
          else if(++matchCount == fields.Count)
            return true;
        }
      
        if(fields.ContainsKey("CompanyId"))
        {
          
              if(!fields["CompanyId"].Equals(this.CompanyId))
            
            return false;
          else if(++matchCount == fields.Count)
            return true;
        }
      
        if(fields.ContainsKey("LanguageId"))
        {
          
              if(!fields["LanguageId"].Equals(this.LanguageId))
            
            return false;
          else if(++matchCount == fields.Count)
            return true;
        }
      
        if(fields.ContainsKey("TimeZoneId"))
        {
          
              if(!fields["TimeZoneId"].Equals(this.TimeZoneId))
            
            return false;
          else if(++matchCount == fields.Count)
            return true;
        }
      
        if(fields.ContainsKey("UserRoleId"))
        {
          
              if(!fields["UserRoleId"].Equals(this.UserRoleId))
            
            return false;
          else if(++matchCount == fields.Count)
            return true;
        }
      
        if(fields.ContainsKey("FirstName"))
        {
          
              if(!fields["FirstName"].Equals(this.FirstName))
            
            return false;
          else if(++matchCount == fields.Count)
            return true;
        }
      
        if(fields.ContainsKey("LastName"))
        {
          
              if(!fields["LastName"].Equals(this.LastName))
            
            return false;
          else if(++matchCount == fields.Count)
            return true;
        }
      
        if(fields.ContainsKey("Password"))
        {
          
              if(!fields["Password"].Equals(this.Password))
            
            return false;
          else if(++matchCount == fields.Count)
            return true;
        }
      
        if(fields.ContainsKey("Email"))
        {
          
              if(!fields["Email"].Equals(this.Email))
            
            return false;
          else if(++matchCount == fields.Count)
            return true;
        }
      
        if(fields.ContainsKey("CreatedBy"))
        {
          
              if(!fields["CreatedBy"].Equals(this.CreatedBy))
            
            return false;
          else if(++matchCount == fields.Count)
            return true;
        }
      
        if(fields.ContainsKey("ModifiedBy"))
        {
          
              if(!fields["ModifiedBy"].Equals(this.ModifiedBy))
            
            return false;
          else if(++matchCount == fields.Count)
            return true;
        }
      
        if(fields.ContainsKey("DateCreated"))
        {
          
              if(!fields["DateCreated"].Equals(this.DateCreated))
            
            return false;
          else if(++matchCount == fields.Count)
            return true;
        }
      
        if(fields.ContainsKey("DateModified"))
        {
          
              if(!fields["DateModified"].Equals(this.DateModified))
            
            return false;
          else if(++matchCount == fields.Count)
            return true;
        }
      
        if(fields.ContainsKey("IsActive"))
        {
          
              if(!fields["IsActive"].Equals(this.IsActive))
            
            return false;
          else if(++matchCount == fields.Count)
            return true;
        }
      
    
      return matchCount == fields.Count;
    }

    public override String  getUri()
    {

    String uri = "EduGameCloud2.EduGameCloud2.dbo.User"
    
      + "." + UserId.ToString()
    ;
    
    return uri;
    }

    

      public int UserId
      {
        
            get { return _userId;}
            set 
            { 
                _userId = value;
            }
          
      }
    

      public int CompanyId
      {
        
            get { return _companyId;}
            set 
            { 
                _companyId = value;
            }
          
      }
    

      public int LanguageId
      {
        
            get { return _languageId;}
            set 
            { 
                _languageId = value;
            }
          
      }
    

      public int TimeZoneId
      {
        
            get { return _timeZoneId;}
            set 
            { 
                _timeZoneId = value;
            }
          
      }
    

      public int UserRoleId
      {
        
            get
            {
            
                  if(_relatedUserRole != null)
                    return _relatedUserRole.UserRoleId;

                throw new NullReferenceException("Parent instance not initialized ");
            }
            set
            {
            
                      if(_relatedUserRole == null)
                        _relatedUserRole = new UserRole();

                      _relatedUserRole.UserRoleId = value;
                    
            }
          
      }
    

      public String FirstName
      {
        
            get { return _firstName;}
            set 
            { 
                _firstName = value;
            }
          
      }
    

      public String LastName
      {
        
            get { return _lastName;}
            set 
            { 
                _lastName = value;
            }
          
      }
    

      public String Password
      {
        
            get { return _password;}
            set 
            { 
                _password = value;
            }
          
      }
    

      public String Email
      {
        
            get { return _email;}
            set 
            { 
                _email = value;
            }
          
      }
    

      public int? CreatedBy
      {
        
            get { return _createdBy;}
            set 
            { 
                _createdBy = value;
            }
          
      }
    

      public int? ModifiedBy
      {
        
            get { return _modifiedBy;}
            set 
            { 
                _modifiedBy = value;
            }
          
      }
    

      public DateTime DateCreated
      {
        
            get { return _dateCreated;}
            set 
            { 
                _dateCreated = value;
            }
          
      }
    

      public DateTime DateModified
      {
        
            get { return _dateModified;}
            set 
            { 
                _dateModified = value;
            }
          
      }
    

      public bool? IsActive
      {
        
            get { return _isActive;}
            set 
            { 
                _isActive = value;
            }
          
      }
    

      public UserRole RelatedUserRole
      {
      get { return _relatedUserRole;}
      set { _relatedUserRole = value; }
      }
      
    

    public override IDataMapper createDataMapper(ITransactionContext transactionContext)
    {
        return new UserDataMapper(
          (EduGameCloud2Db)transactionContext);
    }

    public override DomainObject extractSingleObject()
    {
    User user = new User();
      
      user.UserId = this.UserId;
      user.CompanyId = this.CompanyId;
      user.LanguageId = this.LanguageId;
      user.TimeZoneId = this.TimeZoneId;
      user.UserRoleId = this.UserRoleId;
      user.FirstName = this.FirstName;
      user.LastName = this.LastName;
      user.Password = this.Password;
      user.Email = this.Email;
      user.CreatedBy = this.CreatedBy;
      user.ModifiedBy = this.ModifiedBy;
      user.DateCreated = this.DateCreated;
      user.DateModified = this.DateModified;
      user.IsActive = this.IsActive;
      user.ActiveRecordUID = this.ActiveRecordUID;
    return user;
    }

    
              // one to many relation
              private List<UserActivation> _relatedUserActivation;

              public List<UserActivation> relatedUserActivation
              {
              get { return _relatedUserActivation;}
              set { _relatedUserActivation = value; }
              }


              public UserActivation addRelatedUserActivationItem(
              UserActivation userActivation)
              {
              userActivation.RelatedUser = this;

              _relatedUserActivation.Add(userActivation);

              return userActivation;
              }

            
    }
  

    public abstract class _UserDataMapper:TDataMapper<User,SqlConnection,EduGameCloud2Db, Weborb.Data.Management.MSSql.CommandBuilder, SqlTransaction, SqlCommand>
    {
      public _UserDataMapper(){}
      public _UserDataMapper(EduGameCloud2Db database):
      base(database){}
        public override String TableName
        {
          get
          {
            return "[dbo].[User]";
          }
        }
        
        public override String getSafeName(String name)
        {
          return String.Format("[{0}]",name);
        }

        public override Hashtable getRelation(string tableName)
        {
          throw new Exception("Not yet implemented");
        }

        
    
    private const String SqlCreate = @"Insert Into [dbo].[User] (
    
      [companyId]
      ,
      [languageId]
      ,
      [timeZoneId]
      ,
      [userRoleId]
      ,
      [firstName]
      ,
      [lastName]
      ,
      [password]
      ,
      [email]
      ,
      [createdBy]
      ,
      [modifiedBy]
      ,
      [dateCreated]
      ,
      [dateModified]
      ,
      [isActive]
      ) Values (
    
      @companyId,
      @languageId,
      @timeZoneId,
      @userRoleId,
      @firstName,
      @lastName,
      @password,
      @email,
      @createdBy,
      @modifiedBy,
      @dateCreated,
      @dateModified,
      @isActive);

    
      select scope_identity();
    ";
    
    [TransactionRequired]
    public override User create( User user )
    {
    StartSynchronization();
    
    using (DatabaseConnectionMonitor monitor = new DatabaseConnectionMonitor(Database))
    {
    using(SqlCommand sqlCommand = Database.CreateCommand( SqlCreate ))
    {
    
                  sqlCommand.Parameters.AddWithValue("@companyId", user.CompanyId);
              
                  sqlCommand.Parameters.AddWithValue("@languageId", user.LanguageId);
              
                  sqlCommand.Parameters.AddWithValue("@timeZoneId", user.TimeZoneId);
              
                  sqlCommand.Parameters.AddWithValue("@userRoleId", user.UserRoleId);
              
                  sqlCommand.Parameters.AddWithValue("@firstName", user.FirstName);
              
                    if(user.LastName != null)
                  
                  sqlCommand.Parameters.AddWithValue("@lastName", user.LastName);
                else
                  sqlCommand.Parameters.AddWithValue("@lastName", DBNull.Value);
              
                    if(user.Password != null)
                  
                  sqlCommand.Parameters.AddWithValue("@password", user.Password);
                else
                  sqlCommand.Parameters.AddWithValue("@password", DBNull.Value);
              
                    if(user.Email != null)
                  
                  sqlCommand.Parameters.AddWithValue("@email", user.Email);
                else
                  sqlCommand.Parameters.AddWithValue("@email", DBNull.Value);
              
                    if(user.CreatedBy.HasValue)
                  
                  sqlCommand.Parameters.AddWithValue("@createdBy", user.CreatedBy);
                else
                  sqlCommand.Parameters.AddWithValue("@createdBy", DBNull.Value);
              
                    if(user.ModifiedBy.HasValue)
                  
                  sqlCommand.Parameters.AddWithValue("@modifiedBy", user.ModifiedBy);
                else
                  sqlCommand.Parameters.AddWithValue("@modifiedBy", DBNull.Value);
              
                  sqlCommand.Parameters.AddWithValue("@dateCreated", user.DateCreated);
              
                  sqlCommand.Parameters.AddWithValue("@dateModified", user.DateModified);
              
                    if(user.IsActive.HasValue)
                  
                  sqlCommand.Parameters.AddWithValue("@isActive", user.IsActive);
                else
                  sqlCommand.Parameters.AddWithValue("@isActive", DBNull.Value);
              user.UserId = int.Parse( sqlCommand.ExecuteScalar().ToString()) ;
            
        }
      }
      
    

              if(user.relatedUserActivation != null
              && user.relatedUserActivation.Count > 0)
              {
              UserActivationDataMapper dataMapper = new UserActivationDataMapper(Database);

              foreach(UserActivation item in user.relatedUserActivation)
              dataMapper.create(item);
              }
            
      
      raiseAffected(user,DataMapperOperation.create);

    InvokeSynchronization();
    
    return registerRecord(user);
    }

  

    private const String SqlSelectByPk = @"Select
    
      [userId] ,
      [companyId] ,
      [languageId] ,
      [timeZoneId] ,
      [userRoleId] ,
      [firstName] ,
      [lastName] ,
      [password] ,
      [email] ,
      [createdBy] ,
      [modifiedBy] ,
      [dateCreated] ,
      [dateModified] ,
      [isActive] 
     From [dbo].[User]
    
       Where 
      
         [userId] = @userId
    ";

    public User findByPrimaryKey(
    int userId
    )
    {
    using (DatabaseConnectionMonitor monitor = new DatabaseConnectionMonitor(Database))
    {
    using(SqlCommand sqlCommand = Database.CreateCommand(SqlSelectByPk))
    {
        
          sqlCommand.Parameters.AddWithValue("@userId", userId);
        

        using(IDataReader dataReader = sqlCommand.ExecuteReader())
        {
          if(dataReader.Read())
            return doLoad(dataReader);
        }
      }
     }      
      throw new DataNotFoundException("User not found, search by primary key");
 

    }


    public bool exists(User user)
    {
      using (DatabaseConnectionMonitor monitor = new DatabaseConnectionMonitor(Database))
      {
          using(SqlCommand sqlCommand = Database.CreateCommand(SqlSelectByPk))
          {
              
                sqlCommand.Parameters.AddWithValue("@userId", user.UserId);
              

              using(IDataReader dataReader = sqlCommand.ExecuteReader())
              {
              return dataReader.Read();
              }
          }
      }
    }

    private const string CheckInSql = @"
    
      [User].[userId] = @CheckInuserId";

    protected override IDbCommand prepareCheckInCommand(DomainObject domainObject, string sqlQuery)
    {
      User _User = (User)domainObject;

       SqlCommand sqlCommand = Database.CreateCommand(modifyQueryForCheckIn(sqlQuery,CheckInSql));

      
        sqlCommand.Parameters.AddWithValue("@CheckInuserId", _User.UserId);
      

      return sqlCommand;
    }

  
    
    protected override User doLoad(IDataReader dataReader)
    {
    User user = new User();

    user.UserId = unchecked( (int) dataReader.GetValue(0) );
            user.CompanyId = unchecked( (int) dataReader.GetValue(1) );
            user.LanguageId = unchecked( (int) dataReader.GetValue(2) );
            user.TimeZoneId = unchecked( (int) dataReader.GetValue(3) );
            user.UserRoleId = unchecked( (int) dataReader.GetValue(4) );
            user.FirstName = unchecked( (String) dataReader.GetValue(5) );
            
          if(!dataReader.IsDBNull(6))        
          user.LastName = unchecked( (String) dataReader.GetValue(6) );
            
          if(!dataReader.IsDBNull(7))        
          user.Password = unchecked( (String) dataReader.GetValue(7) );
            
          if(!dataReader.IsDBNull(8))        
          user.Email = unchecked( (String) dataReader.GetValue(8) );
            
          if(!dataReader.IsDBNull(9))        
          user.CreatedBy = unchecked( (int) dataReader.GetValue(9) );
            
          if(!dataReader.IsDBNull(10))        
          user.ModifiedBy = unchecked( (int) dataReader.GetValue(10) );
            user.DateCreated = unchecked( (DateTime) dataReader.GetValue(11) );
            user.DateModified = unchecked( (DateTime) dataReader.GetValue(12) );
            
          if(!dataReader.IsDBNull(13))        
          user.IsActive = unchecked( (bool) dataReader.GetValue(13) );
            

    return registerRecord(user);
    }


    protected override User doLoad(Hashtable hashtable)
    {
      User user = new User();

      
        
        if(hashtable.ContainsKey("userId"))
        user.UserId = unchecked( ( int)hashtable["UserId"] );
          
        
        if(hashtable.ContainsKey("companyId"))
        user.CompanyId = unchecked( ( int)hashtable["CompanyId"] );
          
        
        if(hashtable.ContainsKey("languageId"))
        user.LanguageId = unchecked( ( int)hashtable["LanguageId"] );
          
        
        if(hashtable.ContainsKey("timeZoneId"))
        user.TimeZoneId = unchecked( ( int)hashtable["TimeZoneId"] );
          
        
        if(hashtable.ContainsKey("userRoleId"))
        user.UserRoleId = unchecked( ( int)hashtable["UserRoleId"] );
          
        
        if(hashtable.ContainsKey("firstName"))
        user.FirstName = unchecked( ( String)hashtable["FirstName"] );
          
        
        if(hashtable.ContainsKey("lastName"))
        user.LastName = unchecked( ( String)hashtable["LastName"] );
          
        
        if(hashtable.ContainsKey("password"))
        user.Password = unchecked( ( String)hashtable["Password"] );
          
        
        if(hashtable.ContainsKey("email"))
        user.Email = unchecked( ( String)hashtable["Email"] );
          
        
        if(hashtable.ContainsKey("createdBy"))
        user.CreatedBy = unchecked( ( int)hashtable["CreatedBy"] );
          
        
        if(hashtable.ContainsKey("modifiedBy"))
        user.ModifiedBy = unchecked( ( int)hashtable["ModifiedBy"] );
          
        
        if(hashtable.ContainsKey("dateCreated"))
        user.DateCreated = unchecked( ( DateTime)hashtable["DateCreated"] );
          
        
        if(hashtable.ContainsKey("dateModified"))
        user.DateModified = unchecked( ( DateTime)hashtable["DateModified"] );
          
        
        if(hashtable.ContainsKey("isActive"))
        user.IsActive = unchecked( ( bool)hashtable["IsActive"] );
          

      return user;
    }


    protected override List<User> fill(SqlCommand sqlCommand, int offset, int limit)
    {
         List<User> resultList = new List<User>();
    
         using(SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand))
         {
            DataTable dataTable = new DataTable();
            
            sqlDataAdapter.Fill(offset,limit,dataTable);
            
            foreach(DataRow dataRow in dataTable.Rows)
            {
              User item = new User();
              
              
                    item.UserId = ( int)dataRow["userId"] ;
                  
                    item.CompanyId = ( int)dataRow["companyId"] ;
                  
                    item.LanguageId = ( int)dataRow["languageId"] ;
                  
                    item.TimeZoneId = ( int)dataRow["timeZoneId"] ;
                  
                    item.UserRoleId = ( int)dataRow["userRoleId"] ;
                  
                    item.FirstName = ( String)dataRow["firstName"] ;
                  
                  if(!dataRow.IsNull("lastName"))
                
                    item.LastName = ( String)dataRow["lastName"] ;
                  
                  if(!dataRow.IsNull("password"))
                
                    item.Password = ( String)dataRow["password"] ;
                  
                  if(!dataRow.IsNull("email"))
                
                    item.Email = ( String)dataRow["email"] ;
                  
                  if(!dataRow.IsNull("createdBy"))
                
                    item.CreatedBy = ( int)dataRow["createdBy"] ;
                  
                  if(!dataRow.IsNull("modifiedBy"))
                
                    item.ModifiedBy = ( int)dataRow["modifiedBy"] ;
                  
                    item.DateCreated = ( DateTime)dataRow["dateCreated"] ;
                  
                    item.DateModified = ( DateTime)dataRow["dateModified"] ;
                  
                  if(!dataRow.IsNull("isActive"))
                
                    item.IsActive = ( bool)dataRow["isActive"] ;
                  
    
              registerRecord(item);

              resultList.Add(item);
            }
        }

      return resultList;
    }

    
      private const String SqlFindByRelatedUserRole = @"select * from [dbo].[User]
      where
      
        [userRoleId] = @userRoleId";

      //Note: this function can be called only from server side
      internal List<User> findByRelatedUserRole(UserRole domainObject, QueryOptions queryOptions)
      {
        List<User> result = null;
        
        using(SqlCommand sqlCommand = Database.CreateCommand(SqlFindByRelatedUserRole))
        {
          

            sqlCommand.Parameters.AddWithValue("@userRoleId",
            domainObject.UserRoleId);
          

          result = fill(sqlCommand,0,0);
        }
        
        foreach(User item in result)
          item.RelatedUserRole = domainObject;

         
           loadRelations(result,queryOptions);
         

        return result;
      }

    
      protected override void loadRelations(User domainObject, QueryOptions queryOptions)
      {
      foreach(String relationName in queryOptions.GetRelations(this))
      {
        

                  if(relationName == "RelatedUserActivation")
                  {
                    UserActivationDataMapper dataMapper = new UserActivationDataMapper(Database);

                    domainObject.relatedUserActivation = dataMapper.findByRelatedUser(domainObject,queryOptions);

                  }
                
        }
      }
    
    #region Delete
    private const String SqlDelete = @"Delete From [dbo].[User]
    
      Where
      
        [userId] = @userId";
    [TransactionRequired]
    public override User remove(User user, bool cascade)
    {
    using( SynchronizationScope syncScope = new SynchronizationScope( Database ) )
    {

    using (DatabaseConnectionMonitor monitor = new DatabaseConnectionMonitor(Database))
    {

    if(cascade)
    {
    
              // one to many relation
            UserActivationDataMapper dataMapperUserActivation
          = new UserActivationDataMapper(Database);

          List<UserActivation> itemsUserActivation = dataMapperUserActivation.findByRelatedUser(
           user,
          new QueryOptions(false));

          foreach(UserActivation itemUserActivation in itemsUserActivation)
          dataMapperUserActivation.remove(itemUserActivation,true);
		
    }


    using(SqlCommand sqlCommand = Database.CreateCommand(SqlDelete))
    {
    
            
            sqlCommand.Parameters.AddWithValue("@userId", user.UserId);
          
            sqlCommand.ExecuteNonQuery();
          }
       }
      raiseAffected(user,DataMapperOperation.delete);
      syncScope.Invoke();
      }
      return registerRecord(user);
    }
    
    #endregion
  
    [TransactionRequired]
    public override User save( User user )
    {
      if(exists(user))
        return update(user);
        return create(user);
    }

  
      const String SqlUpdate = @"Update [dbo].[User] Set
      
        [companyId] = @companyId,
        [languageId] = @languageId,
        [timeZoneId] = @timeZoneId,
        [userRoleId] = @userRoleId,
        [firstName] = @firstName,
        [lastName] = @lastName,
        [password] = @password,
        [email] = @email,
        [createdBy] = @createdBy,
        [modifiedBy] = @modifiedBy,
        [dateCreated] = @dateCreated,
        [dateModified] = @dateModified,
        [isActive] = @isActive
        Where
        
          [userId] = @userId";
    [TransactionRequired]
    public override User update(User user)
    {
      
        using( SynchronizationScope syncScope = new SynchronizationScope( Database ) )
        {
        using (DatabaseConnectionMonitor monitor = new DatabaseConnectionMonitor(Database))
        {
        using(SqlCommand sqlCommand = Database.CreateCommand(SqlUpdate))
        {
        
              sqlCommand.Parameters.AddWithValue("@userId", user.UserId);
            
              sqlCommand.Parameters.AddWithValue("@companyId", user.CompanyId);
            
              sqlCommand.Parameters.AddWithValue("@languageId", user.LanguageId);
            
              sqlCommand.Parameters.AddWithValue("@timeZoneId", user.TimeZoneId);
            
              sqlCommand.Parameters.AddWithValue("@userRoleId", user.UserRoleId);
            
              sqlCommand.Parameters.AddWithValue("@firstName", user.FirstName);
            
                  if(user.LastName != null)
                
              sqlCommand.Parameters.AddWithValue("@lastName", user.LastName);
              else
              sqlCommand.Parameters.AddWithValue("@lastName", DBNull.Value);
            
                  if(user.Password != null)
                
              sqlCommand.Parameters.AddWithValue("@password", user.Password);
              else
              sqlCommand.Parameters.AddWithValue("@password", DBNull.Value);
            
                  if(user.Email != null)
                
              sqlCommand.Parameters.AddWithValue("@email", user.Email);
              else
              sqlCommand.Parameters.AddWithValue("@email", DBNull.Value);
            
                  if(user.CreatedBy.HasValue)
                
              sqlCommand.Parameters.AddWithValue("@createdBy", user.CreatedBy);
              else
              sqlCommand.Parameters.AddWithValue("@createdBy", DBNull.Value);
            
                  if(user.ModifiedBy.HasValue)
                
              sqlCommand.Parameters.AddWithValue("@modifiedBy", user.ModifiedBy);
              else
              sqlCommand.Parameters.AddWithValue("@modifiedBy", DBNull.Value);
            
              sqlCommand.Parameters.AddWithValue("@dateCreated", user.DateCreated);
            
              sqlCommand.Parameters.AddWithValue("@dateModified", user.DateModified);
            
                  if(user.IsActive.HasValue)
                
              sqlCommand.Parameters.AddWithValue("@isActive", user.IsActive);
              else
              sqlCommand.Parameters.AddWithValue("@isActive", DBNull.Value);
            


        sqlCommand.ExecuteNonQuery();
        }
        }

        
                  if(user.relatedUserActivation != null
                  && user.relatedUserActivation.Count > 0)
                  {
                  UserActivationDataMapper dataMapper = new UserActivationDataMapper(Database);

                  foreach(UserActivation item in user.relatedUserActivation)
                  dataMapper.save(item);
                  }
                

        raiseAffected(user,DataMapperOperation.update);
        syncScope.Invoke();
        }
        
    
        return registerRecord(user);

    }

  
    }
    
  
    
    public partial class UserActivation: DomainObject
    {
    
      protected int _userActivationId;
    
      protected int _userId;
    
      protected String _activationCode;
    
      protected DateTime _dateExpires;
    

      // parent tables
      protected User _relatedUser;
    

    public UserActivation(){}

    public UserActivation(
    int 
            userActivationId,int 
            userId,String 
            activationCode,DateTime 
            dateExpires
    )
    {
    
      this.UserActivationId = userActivationId;
    
      this.UserId = userId;
    
      this.ActivationCode = activationCode;
    
      this.DateExpires = dateExpires;
    
    }

    public override bool contains(Hashtable fields)
    {
      int matchCount = 0;
      
        if(fields.ContainsKey("UserActivationId"))
        {
          
              if(!fields["UserActivationId"].Equals(this.UserActivationId))
            
            return false;
          else if(++matchCount == fields.Count)
            return true;
        }
      
        if(fields.ContainsKey("UserId"))
        {
          
              if(!fields["UserId"].Equals(this.UserId))
            
            return false;
          else if(++matchCount == fields.Count)
            return true;
        }
      
        if(fields.ContainsKey("ActivationCode"))
        {
          
              if(!fields["ActivationCode"].Equals(this.ActivationCode))
            
            return false;
          else if(++matchCount == fields.Count)
            return true;
        }
      
        if(fields.ContainsKey("DateExpires"))
        {
          
              if(!fields["DateExpires"].Equals(this.DateExpires))
            
            return false;
          else if(++matchCount == fields.Count)
            return true;
        }
      
    
      return matchCount == fields.Count;
    }

    public override String  getUri()
    {

    String uri = "EduGameCloud2.EduGameCloud2.dbo.UserActivation"
    
      + "." + UserActivationId.ToString()
    ;
    
    return uri;
    }

    

      public int UserActivationId
      {
        
            get { return _userActivationId;}
            set 
            { 
                _userActivationId = value;
            }
          
      }
    

      public int UserId
      {
        
            get
            {
            
                  if(_relatedUser != null)
                    return _relatedUser.UserId;

                throw new NullReferenceException("Parent instance not initialized ");
            }
            set
            {
            
                      if(_relatedUser == null)
                        _relatedUser = new User();

                      _relatedUser.UserId = value;
                    
            }
          
      }
    

      public String ActivationCode
      {
        
            get { return _activationCode;}
            set 
            { 
                _activationCode = value;
            }
          
      }
    

      public DateTime DateExpires
      {
        
            get { return _dateExpires;}
            set 
            { 
                _dateExpires = value;
            }
          
      }
    

      public User RelatedUser
      {
      get { return _relatedUser;}
      set { _relatedUser = value; }
      }
      
    

    public override IDataMapper createDataMapper(ITransactionContext transactionContext)
    {
        return new UserActivationDataMapper(
          (EduGameCloud2Db)transactionContext);
    }

    public override DomainObject extractSingleObject()
    {
    UserActivation userActivation = new UserActivation();
      
      userActivation.UserActivationId = this.UserActivationId;
      userActivation.UserId = this.UserId;
      userActivation.ActivationCode = this.ActivationCode;
      userActivation.DateExpires = this.DateExpires;
      userActivation.ActiveRecordUID = this.ActiveRecordUID;
    return userActivation;
    }

    
    }
  

    public abstract class _UserActivationDataMapper:TDataMapper<UserActivation,SqlConnection,EduGameCloud2Db, Weborb.Data.Management.MSSql.CommandBuilder, SqlTransaction, SqlCommand>
    {
      public _UserActivationDataMapper(){}
      public _UserActivationDataMapper(EduGameCloud2Db database):
      base(database){}
        public override String TableName
        {
          get
          {
            return "[dbo].[UserActivation]";
          }
        }
        
        public override String getSafeName(String name)
        {
          return String.Format("[{0}]",name);
        }

        public override Hashtable getRelation(string tableName)
        {
          throw new Exception("Not yet implemented");
        }

        
    
    private const String SqlCreate = @"Insert Into [dbo].[UserActivation] (
    
      [userId]
      ,
      [activationCode]
      ,
      [dateExpires]
      ) Values (
    
      @userId,
      @activationCode,
      @dateExpires);

    
      select scope_identity();
    ";
    
    
    public override UserActivation create( UserActivation userActivation )
    {
    StartSynchronization();
    
    using (DatabaseConnectionMonitor monitor = new DatabaseConnectionMonitor(Database))
    {
    using(SqlCommand sqlCommand = Database.CreateCommand( SqlCreate ))
    {
    
                  sqlCommand.Parameters.AddWithValue("@userId", userActivation.UserId);
              
                  sqlCommand.Parameters.AddWithValue("@activationCode", userActivation.ActivationCode);
              
                  sqlCommand.Parameters.AddWithValue("@dateExpires", userActivation.DateExpires);
              userActivation.UserActivationId = int.Parse( sqlCommand.ExecuteScalar().ToString()) ;
            
        }
      }
      
    
      
      raiseAffected(userActivation,DataMapperOperation.create);

    InvokeSynchronization();
    
    return registerRecord(userActivation);
    }

  

    private const String SqlSelectByPk = @"Select
    
      [userActivationId] ,
      [userId] ,
      [activationCode] ,
      [dateExpires] 
     From [dbo].[UserActivation]
    
       Where 
      
         [userActivationId] = @userActivationId
    ";

    public UserActivation findByPrimaryKey(
    int userActivationId
    )
    {
    using (DatabaseConnectionMonitor monitor = new DatabaseConnectionMonitor(Database))
    {
    using(SqlCommand sqlCommand = Database.CreateCommand(SqlSelectByPk))
    {
        
          sqlCommand.Parameters.AddWithValue("@userActivationId", userActivationId);
        

        using(IDataReader dataReader = sqlCommand.ExecuteReader())
        {
          if(dataReader.Read())
            return doLoad(dataReader);
        }
      }
     }      
      throw new DataNotFoundException("UserActivation not found, search by primary key");
 

    }


    public bool exists(UserActivation userActivation)
    {
      using (DatabaseConnectionMonitor monitor = new DatabaseConnectionMonitor(Database))
      {
          using(SqlCommand sqlCommand = Database.CreateCommand(SqlSelectByPk))
          {
              
                sqlCommand.Parameters.AddWithValue("@userActivationId", userActivation.UserActivationId);
              

              using(IDataReader dataReader = sqlCommand.ExecuteReader())
              {
              return dataReader.Read();
              }
          }
      }
    }

    private const string CheckInSql = @"
    
      [UserActivation].[userActivationId] = @CheckInuserActivationId";

    protected override IDbCommand prepareCheckInCommand(DomainObject domainObject, string sqlQuery)
    {
      UserActivation _UserActivation = (UserActivation)domainObject;

       SqlCommand sqlCommand = Database.CreateCommand(modifyQueryForCheckIn(sqlQuery,CheckInSql));

      
        sqlCommand.Parameters.AddWithValue("@CheckInuserActivationId", _UserActivation.UserActivationId);
      

      return sqlCommand;
    }

  
    
    protected override UserActivation doLoad(IDataReader dataReader)
    {
    UserActivation userActivation = new UserActivation();

    userActivation.UserActivationId = unchecked( (int) dataReader.GetValue(0) );
            userActivation.UserId = unchecked( (int) dataReader.GetValue(1) );
            userActivation.ActivationCode = unchecked( (String) dataReader.GetValue(2) );
            userActivation.DateExpires = unchecked( (DateTime) dataReader.GetValue(3) );
            

    return registerRecord(userActivation);
    }


    protected override UserActivation doLoad(Hashtable hashtable)
    {
      UserActivation userActivation = new UserActivation();

      
        
        if(hashtable.ContainsKey("userActivationId"))
        userActivation.UserActivationId = unchecked( ( int)hashtable["UserActivationId"] );
          
        
        if(hashtable.ContainsKey("userId"))
        userActivation.UserId = unchecked( ( int)hashtable["UserId"] );
          
        
        if(hashtable.ContainsKey("activationCode"))
        userActivation.ActivationCode = unchecked( ( String)hashtable["ActivationCode"] );
          
        
        if(hashtable.ContainsKey("dateExpires"))
        userActivation.DateExpires = unchecked( ( DateTime)hashtable["DateExpires"] );
          

      return userActivation;
    }


    protected override List<UserActivation> fill(SqlCommand sqlCommand, int offset, int limit)
    {
         List<UserActivation> resultList = new List<UserActivation>();
    
         using(SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand))
         {
            DataTable dataTable = new DataTable();
            
            sqlDataAdapter.Fill(offset,limit,dataTable);
            
            foreach(DataRow dataRow in dataTable.Rows)
            {
              UserActivation item = new UserActivation();
              
              
                    item.UserActivationId = ( int)dataRow["userActivationId"] ;
                  
                    item.UserId = ( int)dataRow["userId"] ;
                  
                    item.ActivationCode = ( String)dataRow["activationCode"] ;
                  
                    item.DateExpires = ( DateTime)dataRow["dateExpires"] ;
                  
    
              registerRecord(item);

              resultList.Add(item);
            }
        }

      return resultList;
    }

    
      private const String SqlFindByRelatedUser = @"select * from [dbo].[UserActivation]
      where
      
        [userId] = @userId";

      //Note: this function can be called only from server side
      internal List<UserActivation> findByRelatedUser(User domainObject, QueryOptions queryOptions)
      {
        List<UserActivation> result = null;
        
        using(SqlCommand sqlCommand = Database.CreateCommand(SqlFindByRelatedUser))
        {
          

            sqlCommand.Parameters.AddWithValue("@userId",
            domainObject.UserId);
          

          result = fill(sqlCommand,0,0);
        }
        
        foreach(UserActivation item in result)
          item.RelatedUser = domainObject;

         

        return result;
      }

    
    #region Delete
    private const String SqlDelete = @"Delete From [dbo].[UserActivation]
    
      Where
      
        [userActivationId] = @userActivationId";
    [TransactionRequired]
    public override UserActivation remove(UserActivation userActivation, bool cascade)
    {
    using( SynchronizationScope syncScope = new SynchronizationScope( Database ) )
    {

    using (DatabaseConnectionMonitor monitor = new DatabaseConnectionMonitor(Database))
    {

    if(cascade)
    {
    
    }


    using(SqlCommand sqlCommand = Database.CreateCommand(SqlDelete))
    {
    
            
            sqlCommand.Parameters.AddWithValue("@userActivationId", userActivation.UserActivationId);
          
            sqlCommand.ExecuteNonQuery();
          }
       }
      raiseAffected(userActivation,DataMapperOperation.delete);
      syncScope.Invoke();
      }
      return registerRecord(userActivation);
    }
    
    #endregion
  
    [TransactionRequired]
    public override UserActivation save( UserActivation userActivation )
    {
      if(exists(userActivation))
        return update(userActivation);
        return create(userActivation);
    }

  
      const String SqlUpdate = @"Update [dbo].[UserActivation] Set
      
        [userId] = @userId,
        [activationCode] = @activationCode,
        [dateExpires] = @dateExpires
        Where
        
          [userActivationId] = @userActivationId";
    
    public override UserActivation update(UserActivation userActivation)
    {
      
        using( SynchronizationScope syncScope = new SynchronizationScope( Database ) )
        {
        using (DatabaseConnectionMonitor monitor = new DatabaseConnectionMonitor(Database))
        {
        using(SqlCommand sqlCommand = Database.CreateCommand(SqlUpdate))
        {
        
              sqlCommand.Parameters.AddWithValue("@userActivationId", userActivation.UserActivationId);
            
              sqlCommand.Parameters.AddWithValue("@userId", userActivation.UserId);
            
              sqlCommand.Parameters.AddWithValue("@activationCode", userActivation.ActivationCode);
            
              sqlCommand.Parameters.AddWithValue("@dateExpires", userActivation.DateExpires);
            


        sqlCommand.ExecuteNonQuery();
        }
        }

        

        raiseAffected(userActivation,DataMapperOperation.update);
        syncScope.Invoke();
        }
        
    
        return registerRecord(userActivation);

    }

  
    }
    
  
    
    public partial class UserRole: DomainObject
    {
    
      protected int _userRoleId;
    
      protected String _userRoleName;
    

    public UserRole(){}

    public UserRole(
    int 
            userRoleId,String 
            userRoleName
    )
    {
    
      this.UserRoleId = userRoleId;
    
      this.UserRoleName = userRoleName;
    
    }

    public override bool contains(Hashtable fields)
    {
      int matchCount = 0;
      
        if(fields.ContainsKey("UserRoleId"))
        {
          
              if(!fields["UserRoleId"].Equals(this.UserRoleId))
            
            return false;
          else if(++matchCount == fields.Count)
            return true;
        }
      
        if(fields.ContainsKey("UserRoleName"))
        {
          
              if(!fields["UserRoleName"].Equals(this.UserRoleName))
            
            return false;
          else if(++matchCount == fields.Count)
            return true;
        }
      
    
      return matchCount == fields.Count;
    }

    public override String  getUri()
    {

    String uri = "EduGameCloud2.EduGameCloud2.dbo.UserRole"
    
      + "." + UserRoleId.ToString()
    ;
    
    return uri;
    }

    

      public int UserRoleId
      {
        
            get { return _userRoleId;}
            set 
            { 
                _userRoleId = value;
            }
          
      }
    

      public String UserRoleName
      {
        
            get { return _userRoleName;}
            set 
            { 
                _userRoleName = value;
            }
          
      }
    

    public override IDataMapper createDataMapper(ITransactionContext transactionContext)
    {
        return new UserRoleDataMapper(
          (EduGameCloud2Db)transactionContext);
    }

    public override DomainObject extractSingleObject()
    {
    UserRole userRole = new UserRole();
      
      userRole.UserRoleId = this.UserRoleId;
      userRole.UserRoleName = this.UserRoleName;
      userRole.ActiveRecordUID = this.ActiveRecordUID;
    return userRole;
    }

    
              // one to many relation
              private List<User> _relatedUser;

              public List<User> relatedUser
              {
              get { return _relatedUser;}
              set { _relatedUser = value; }
              }


              public User addRelatedUserItem(
              User user)
              {
              user.RelatedUserRole = this;

              _relatedUser.Add(user);

              return user;
              }

            
    }
  

    public abstract class _UserRoleDataMapper:TDataMapper<UserRole,SqlConnection,EduGameCloud2Db, Weborb.Data.Management.MSSql.CommandBuilder, SqlTransaction, SqlCommand>
    {
      public _UserRoleDataMapper(){}
      public _UserRoleDataMapper(EduGameCloud2Db database):
      base(database){}
        public override String TableName
        {
          get
          {
            return "[dbo].[UserRole]";
          }
        }
        
        public override String getSafeName(String name)
        {
          return String.Format("[{0}]",name);
        }

        public override Hashtable getRelation(string tableName)
        {
          throw new Exception("Not yet implemented");
        }

        
    
    private const String SqlCreate = @"Insert Into [dbo].[UserRole] (
    
      [userRoleName]
      ) Values (
    
      @userRoleName);

    
      select scope_identity();
    ";
    
    [TransactionRequired]
    public override UserRole create( UserRole userRole )
    {
    StartSynchronization();
    
    using (DatabaseConnectionMonitor monitor = new DatabaseConnectionMonitor(Database))
    {
    using(SqlCommand sqlCommand = Database.CreateCommand( SqlCreate ))
    {
    
                  sqlCommand.Parameters.AddWithValue("@userRoleName", userRole.UserRoleName);
              userRole.UserRoleId = int.Parse( sqlCommand.ExecuteScalar().ToString()) ;
            
        }
      }
      
    

              if(userRole.relatedUser != null
              && userRole.relatedUser.Count > 0)
              {
              UserDataMapper dataMapper = new UserDataMapper(Database);

              foreach(User item in userRole.relatedUser)
              dataMapper.create(item);
              }
            
      
      raiseAffected(userRole,DataMapperOperation.create);

    InvokeSynchronization();
    
    return registerRecord(userRole);
    }

  

    private const String SqlSelectByPk = @"Select
    
      [userRoleId] ,
      [userRoleName] 
     From [dbo].[UserRole]
    
       Where 
      
         [userRoleId] = @userRoleId
    ";

    public UserRole findByPrimaryKey(
    int userRoleId
    )
    {
    using (DatabaseConnectionMonitor monitor = new DatabaseConnectionMonitor(Database))
    {
    using(SqlCommand sqlCommand = Database.CreateCommand(SqlSelectByPk))
    {
        
          sqlCommand.Parameters.AddWithValue("@userRoleId", userRoleId);
        

        using(IDataReader dataReader = sqlCommand.ExecuteReader())
        {
          if(dataReader.Read())
            return doLoad(dataReader);
        }
      }
     }      
      throw new DataNotFoundException("UserRole not found, search by primary key");
 

    }


    public bool exists(UserRole userRole)
    {
      using (DatabaseConnectionMonitor monitor = new DatabaseConnectionMonitor(Database))
      {
          using(SqlCommand sqlCommand = Database.CreateCommand(SqlSelectByPk))
          {
              
                sqlCommand.Parameters.AddWithValue("@userRoleId", userRole.UserRoleId);
              

              using(IDataReader dataReader = sqlCommand.ExecuteReader())
              {
              return dataReader.Read();
              }
          }
      }
    }

    private const string CheckInSql = @"
    
      [UserRole].[userRoleId] = @CheckInuserRoleId";

    protected override IDbCommand prepareCheckInCommand(DomainObject domainObject, string sqlQuery)
    {
      UserRole _UserRole = (UserRole)domainObject;

       SqlCommand sqlCommand = Database.CreateCommand(modifyQueryForCheckIn(sqlQuery,CheckInSql));

      
        sqlCommand.Parameters.AddWithValue("@CheckInuserRoleId", _UserRole.UserRoleId);
      

      return sqlCommand;
    }

  
    
    protected override UserRole doLoad(IDataReader dataReader)
    {
    UserRole userRole = new UserRole();

    userRole.UserRoleId = unchecked( (int) dataReader.GetValue(0) );
            userRole.UserRoleName = unchecked( (String) dataReader.GetValue(1) );
            

    return registerRecord(userRole);
    }


    protected override UserRole doLoad(Hashtable hashtable)
    {
      UserRole userRole = new UserRole();

      
        
        if(hashtable.ContainsKey("userRoleId"))
        userRole.UserRoleId = unchecked( ( int)hashtable["UserRoleId"] );
          
        
        if(hashtable.ContainsKey("userRoleName"))
        userRole.UserRoleName = unchecked( ( String)hashtable["UserRoleName"] );
          

      return userRole;
    }


    protected override List<UserRole> fill(SqlCommand sqlCommand, int offset, int limit)
    {
         List<UserRole> resultList = new List<UserRole>();
    
         using(SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand))
         {
            DataTable dataTable = new DataTable();
            
            sqlDataAdapter.Fill(offset,limit,dataTable);
            
            foreach(DataRow dataRow in dataTable.Rows)
            {
              UserRole item = new UserRole();
              
              
                    item.UserRoleId = ( int)dataRow["userRoleId"] ;
                  
                    item.UserRoleName = ( String)dataRow["userRoleName"] ;
                  
    
              registerRecord(item);

              resultList.Add(item);
            }
        }

      return resultList;
    }

    
      protected override void loadRelations(UserRole domainObject, QueryOptions queryOptions)
      {
      foreach(String relationName in queryOptions.GetRelations(this))
      {
        

                  if(relationName == "RelatedUser")
                  {
                    UserDataMapper dataMapper = new UserDataMapper(Database);

                    domainObject.relatedUser = dataMapper.findByRelatedUserRole(domainObject,queryOptions);

                  }
                
        }
      }
    
    #region Delete
    private const String SqlDelete = @"Delete From [dbo].[UserRole]
    
      Where
      
        [userRoleId] = @userRoleId";
    [TransactionRequired]
    public override UserRole remove(UserRole userRole, bool cascade)
    {
    using( SynchronizationScope syncScope = new SynchronizationScope( Database ) )
    {

    using (DatabaseConnectionMonitor monitor = new DatabaseConnectionMonitor(Database))
    {

    if(cascade)
    {
    
              // one to many relation
            UserDataMapper dataMapperUser
          = new UserDataMapper(Database);

          List<User> itemsUser = dataMapperUser.findByRelatedUserRole(
           userRole,
          new QueryOptions(false));

          foreach(User itemUser in itemsUser)
          dataMapperUser.remove(itemUser,true);
		
    }


    using(SqlCommand sqlCommand = Database.CreateCommand(SqlDelete))
    {
    
            
            sqlCommand.Parameters.AddWithValue("@userRoleId", userRole.UserRoleId);
          
            sqlCommand.ExecuteNonQuery();
          }
       }
      raiseAffected(userRole,DataMapperOperation.delete);
      syncScope.Invoke();
      }
      return registerRecord(userRole);
    }
    
    #endregion
  
    [TransactionRequired]
    public override UserRole save( UserRole userRole )
    {
      if(exists(userRole))
        return update(userRole);
        return create(userRole);
    }

  
      const String SqlUpdate = @"Update [dbo].[UserRole] Set
      
        [userRoleName] = @userRoleName
        Where
        
          [userRoleId] = @userRoleId";
    [TransactionRequired]
    public override UserRole update(UserRole userRole)
    {
      
        using( SynchronizationScope syncScope = new SynchronizationScope( Database ) )
        {
        using (DatabaseConnectionMonitor monitor = new DatabaseConnectionMonitor(Database))
        {
        using(SqlCommand sqlCommand = Database.CreateCommand(SqlUpdate))
        {
        
              sqlCommand.Parameters.AddWithValue("@userRoleId", userRole.UserRoleId);
            
              sqlCommand.Parameters.AddWithValue("@userRoleName", userRole.UserRoleName);
            


        sqlCommand.ExecuteNonQuery();
        }
        }

        
                  if(userRole.relatedUser != null
                  && userRole.relatedUser.Count > 0)
                  {
                  UserDataMapper dataMapper = new UserDataMapper(Database);

                  foreach(User item in userRole.relatedUser)
                  dataMapper.save(item);
                  }
                

        raiseAffected(userRole,DataMapperOperation.update);
        syncScope.Invoke();
        }
        
    
        return registerRecord(userRole);

    }

  
    }
    
  
      }
    