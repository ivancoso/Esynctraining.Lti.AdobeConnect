
        namespace EduGameCloud2
        {
        public partial class User
        {

        }
        }
      