
        namespace EduGameCloud2
        {
        public partial class UserActivation
        {

        }
        }
      