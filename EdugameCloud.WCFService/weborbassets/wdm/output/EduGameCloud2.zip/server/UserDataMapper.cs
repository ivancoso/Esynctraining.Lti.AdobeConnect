
        namespace EduGameCloud2
        {
        public class UserDataMapper :_UserDataMapper
        {
        public UserDataMapper()
        {}
        public UserDataMapper(EduGameCloud2Db database):base(database)
        {}
        }
        }
      