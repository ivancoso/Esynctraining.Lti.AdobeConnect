
        namespace EdugameCloud
        {
        public partial class ACUserMode
        {

        }
        }
      