
        namespace EdugameCloud
        {
        public class LanguageDataMapper :_LanguageDataMapper
        {
        public LanguageDataMapper()
        {}
        public LanguageDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      