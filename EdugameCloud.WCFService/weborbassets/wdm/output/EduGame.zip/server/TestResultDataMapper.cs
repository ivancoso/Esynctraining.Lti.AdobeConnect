
        namespace EdugameCloud
        {
        public class TestResultDataMapper :_TestResultDataMapper
        {
        public TestResultDataMapper()
        {}
        public TestResultDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      