
        namespace EdugameCloud
        {
        public partial class SurveyResult
        {

        }
        }
      