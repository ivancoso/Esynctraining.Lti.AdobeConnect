
        namespace EdugameCloud
        {
        public class QuestionHistoryDataMapper :_QuestionHistoryDataMapper
        {
        public QuestionHistoryDataMapper()
        {}
        public QuestionHistoryDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      