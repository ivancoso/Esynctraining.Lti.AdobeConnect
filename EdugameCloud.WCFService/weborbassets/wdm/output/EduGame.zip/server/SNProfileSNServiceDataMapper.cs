
        namespace EdugameCloud
        {
        public class SNProfileSNServiceDataMapper :_SNProfileSNServiceDataMapper
        {
        public SNProfileSNServiceDataMapper()
        {}
        public SNProfileSNServiceDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      