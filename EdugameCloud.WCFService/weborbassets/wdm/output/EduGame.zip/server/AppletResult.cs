
        namespace EdugameCloud
        {
        public partial class AppletResult
        {

        }
        }
      