
        namespace EdugameCloud
        {
        public class SurveyResultDataMapper :_SurveyResultDataMapper
        {
        public SurveyResultDataMapper()
        {}
        public SurveyResultDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      