
        namespace EdugameCloud
        {
        public class TimeZoneDataMapper :_TimeZoneDataMapper
        {
        public TimeZoneDataMapper()
        {}
        public TimeZoneDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      