
        namespace EdugameCloud
        {
        public class UserDataMapper :_UserDataMapper
        {
        public UserDataMapper()
        {}
        public UserDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      