
        namespace EdugameCloud
        {
        public partial class Company
        {

        }
        }
      