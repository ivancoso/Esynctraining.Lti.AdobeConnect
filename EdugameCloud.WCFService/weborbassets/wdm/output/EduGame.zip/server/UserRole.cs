
        namespace EdugameCloud
        {
        public partial class UserRole
        {

        }
        }
      