
          namespace EdugameCloud
          {
          using System;
          
    using System.Data;
    using System.Collections;
    using System.Collections.Generic;
    using Weborb.Data.Management;

    
    using System.Data.SqlClient;
  
    public partial class EduGameCloudDb:TDatabase<SqlConnection,SqlTransaction,SqlCommand>
    {
      public EduGameCloudDb()
      {
        InitConnectionString("EduGameCloud");
      }

    

        public ACSession create(ACSession aCSession)
        {
          ACSessionDataMapper dataMapper = new ACSessionDataMapper(this);
          
          return dataMapper.create(aCSession);
        }

        public ACSession update(ACSession aCSession)
        {
          ACSessionDataMapper dataMapper = new ACSessionDataMapper(this);

          return dataMapper.update(aCSession);
        }

        public ACSession remove(ACSession aCSession, bool cascade)
        {
          ACSessionDataMapper dataMapper = new ACSessionDataMapper(this);

          return dataMapper.remove(aCSession, cascade);
        }
    

        public ACUserMode create(ACUserMode aCUserMode)
        {
          ACUserModeDataMapper dataMapper = new ACUserModeDataMapper(this);
          
          return dataMapper.create(aCUserMode);
        }

        public ACUserMode update(ACUserMode aCUserMode)
        {
          ACUserModeDataMapper dataMapper = new ACUserModeDataMapper(this);

          return dataMapper.update(aCUserMode);
        }

        public ACUserMode remove(ACUserMode aCUserMode, bool cascade)
        {
          ACUserModeDataMapper dataMapper = new ACUserModeDataMapper(this);

          return dataMapper.remove(aCUserMode, cascade);
        }
    

        public Address create(Address address)
        {
          AddressDataMapper dataMapper = new AddressDataMapper(this);
          
          return dataMapper.create(address);
        }

        public Address update(Address address)
        {
          AddressDataMapper dataMapper = new AddressDataMapper(this);

          return dataMapper.update(address);
        }

        public Address remove(Address address, bool cascade)
        {
          AddressDataMapper dataMapper = new AddressDataMapper(this);

          return dataMapper.remove(address, cascade);
        }
    

        public AppletItem create(AppletItem appletItem)
        {
          AppletItemDataMapper dataMapper = new AppletItemDataMapper(this);
          
          return dataMapper.create(appletItem);
        }

        public AppletItem update(AppletItem appletItem)
        {
          AppletItemDataMapper dataMapper = new AppletItemDataMapper(this);

          return dataMapper.update(appletItem);
        }

        public AppletItem remove(AppletItem appletItem, bool cascade)
        {
          AppletItemDataMapper dataMapper = new AppletItemDataMapper(this);

          return dataMapper.remove(appletItem, cascade);
        }
    

        public AppletResult create(AppletResult appletResult)
        {
          AppletResultDataMapper dataMapper = new AppletResultDataMapper(this);
          
          return dataMapper.create(appletResult);
        }

        public AppletResult update(AppletResult appletResult)
        {
          AppletResultDataMapper dataMapper = new AppletResultDataMapper(this);

          return dataMapper.update(appletResult);
        }

        public AppletResult remove(AppletResult appletResult, bool cascade)
        {
          AppletResultDataMapper dataMapper = new AppletResultDataMapper(this);

          return dataMapper.remove(appletResult, cascade);
        }
    

        public ApplicationVersion create(ApplicationVersion applicationVersion)
        {
          ApplicationVersionDataMapper dataMapper = new ApplicationVersionDataMapper(this);
          
          return dataMapper.create(applicationVersion);
        }

        public ApplicationVersion update(ApplicationVersion applicationVersion)
        {
          ApplicationVersionDataMapper dataMapper = new ApplicationVersionDataMapper(this);

          return dataMapper.update(applicationVersion);
        }

        public ApplicationVersion remove(ApplicationVersion applicationVersion, bool cascade)
        {
          ApplicationVersionDataMapper dataMapper = new ApplicationVersionDataMapper(this);

          return dataMapper.remove(applicationVersion, cascade);
        }
    

        public Company create(Company company)
        {
          CompanyDataMapper dataMapper = new CompanyDataMapper(this);
          
          return dataMapper.create(company);
        }

        public Company update(Company company)
        {
          CompanyDataMapper dataMapper = new CompanyDataMapper(this);

          return dataMapper.update(company);
        }

        public Company remove(Company company, bool cascade)
        {
          CompanyDataMapper dataMapper = new CompanyDataMapper(this);

          return dataMapper.remove(company, cascade);
        }
    

        public CompanyLicense create(CompanyLicense companyLicense)
        {
          CompanyLicenseDataMapper dataMapper = new CompanyLicenseDataMapper(this);
          
          return dataMapper.create(companyLicense);
        }

        public CompanyLicense update(CompanyLicense companyLicense)
        {
          CompanyLicenseDataMapper dataMapper = new CompanyLicenseDataMapper(this);

          return dataMapper.update(companyLicense);
        }

        public CompanyLicense remove(CompanyLicense companyLicense, bool cascade)
        {
          CompanyLicenseDataMapper dataMapper = new CompanyLicenseDataMapper(this);

          return dataMapper.remove(companyLicense, cascade);
        }
    

        public CompanyLicenseHistory create(CompanyLicenseHistory companyLicenseHistory)
        {
          CompanyLicenseHistoryDataMapper dataMapper = new CompanyLicenseHistoryDataMapper(this);
          
          return dataMapper.create(companyLicenseHistory);
        }

        public CompanyLicenseHistory update(CompanyLicenseHistory companyLicenseHistory)
        {
          CompanyLicenseHistoryDataMapper dataMapper = new CompanyLicenseHistoryDataMapper(this);

          return dataMapper.update(companyLicenseHistory);
        }

        public CompanyLicenseHistory remove(CompanyLicenseHistory companyLicenseHistory, bool cascade)
        {
          CompanyLicenseHistoryDataMapper dataMapper = new CompanyLicenseHistoryDataMapper(this);

          return dataMapper.remove(companyLicenseHistory, cascade);
        }
    

        public CompanyTheme create(CompanyTheme companyTheme)
        {
          CompanyThemeDataMapper dataMapper = new CompanyThemeDataMapper(this);
          
          return dataMapper.create(companyTheme);
        }

        public CompanyTheme update(CompanyTheme companyTheme)
        {
          CompanyThemeDataMapper dataMapper = new CompanyThemeDataMapper(this);

          return dataMapper.update(companyTheme);
        }

        public CompanyTheme remove(CompanyTheme companyTheme, bool cascade)
        {
          CompanyThemeDataMapper dataMapper = new CompanyThemeDataMapper(this);

          return dataMapper.remove(companyTheme, cascade);
        }
    

        public CompanyThemeAdmin create(CompanyThemeAdmin companyThemeAdmin)
        {
          CompanyThemeAdminDataMapper dataMapper = new CompanyThemeAdminDataMapper(this);
          
          return dataMapper.create(companyThemeAdmin);
        }

        public CompanyThemeAdmin update(CompanyThemeAdmin companyThemeAdmin)
        {
          CompanyThemeAdminDataMapper dataMapper = new CompanyThemeAdminDataMapper(this);

          return dataMapper.update(companyThemeAdmin);
        }

        public CompanyThemeAdmin remove(CompanyThemeAdmin companyThemeAdmin, bool cascade)
        {
          CompanyThemeAdminDataMapper dataMapper = new CompanyThemeAdminDataMapper(this);

          return dataMapper.remove(companyThemeAdmin, cascade);
        }
    

        public CompanyThemeLogin create(CompanyThemeLogin companyThemeLogin)
        {
          CompanyThemeLoginDataMapper dataMapper = new CompanyThemeLoginDataMapper(this);
          
          return dataMapper.create(companyThemeLogin);
        }

        public CompanyThemeLogin update(CompanyThemeLogin companyThemeLogin)
        {
          CompanyThemeLoginDataMapper dataMapper = new CompanyThemeLoginDataMapper(this);

          return dataMapper.update(companyThemeLogin);
        }

        public CompanyThemeLogin remove(CompanyThemeLogin companyThemeLogin, bool cascade)
        {
          CompanyThemeLoginDataMapper dataMapper = new CompanyThemeLoginDataMapper(this);

          return dataMapper.remove(companyThemeLogin, cascade);
        }
    

        public CompanyThemeMeeting create(CompanyThemeMeeting companyThemeMeeting)
        {
          CompanyThemeMeetingDataMapper dataMapper = new CompanyThemeMeetingDataMapper(this);
          
          return dataMapper.create(companyThemeMeeting);
        }

        public CompanyThemeMeeting update(CompanyThemeMeeting companyThemeMeeting)
        {
          CompanyThemeMeetingDataMapper dataMapper = new CompanyThemeMeetingDataMapper(this);

          return dataMapper.update(companyThemeMeeting);
        }

        public CompanyThemeMeeting remove(CompanyThemeMeeting companyThemeMeeting, bool cascade)
        {
          CompanyThemeMeetingDataMapper dataMapper = new CompanyThemeMeetingDataMapper(this);

          return dataMapper.remove(companyThemeMeeting, cascade);
        }
    

        public Country create(Country country)
        {
          CountryDataMapper dataMapper = new CountryDataMapper(this);
          
          return dataMapper.create(country);
        }

        public Country update(Country country)
        {
          CountryDataMapper dataMapper = new CountryDataMapper(this);

          return dataMapper.update(country);
        }

        public Country remove(Country country, bool cascade)
        {
          CountryDataMapper dataMapper = new CountryDataMapper(this);

          return dataMapper.remove(country, cascade);
        }
    

        public Distractor create(Distractor distractor)
        {
          DistractorDataMapper dataMapper = new DistractorDataMapper(this);
          
          return dataMapper.create(distractor);
        }

        public Distractor update(Distractor distractor)
        {
          DistractorDataMapper dataMapper = new DistractorDataMapper(this);

          return dataMapper.update(distractor);
        }

        public Distractor remove(Distractor distractor, bool cascade)
        {
          DistractorDataMapper dataMapper = new DistractorDataMapper(this);

          return dataMapper.remove(distractor, cascade);
        }
    

        public DistractorHistory create(DistractorHistory distractorHistory)
        {
          DistractorHistoryDataMapper dataMapper = new DistractorHistoryDataMapper(this);
          
          return dataMapper.create(distractorHistory);
        }

        public DistractorHistory update(DistractorHistory distractorHistory)
        {
          DistractorHistoryDataMapper dataMapper = new DistractorHistoryDataMapper(this);

          return dataMapper.update(distractorHistory);
        }

        public DistractorHistory remove(DistractorHistory distractorHistory, bool cascade)
        {
          DistractorHistoryDataMapper dataMapper = new DistractorHistoryDataMapper(this);

          return dataMapper.remove(distractorHistory, cascade);
        }
    

        public ErrorReport create(ErrorReport errorReport)
        {
          ErrorReportDataMapper dataMapper = new ErrorReportDataMapper(this);
          
          return dataMapper.create(errorReport);
        }

        public ErrorReport update(ErrorReport errorReport)
        {
          ErrorReportDataMapper dataMapper = new ErrorReportDataMapper(this);

          return dataMapper.update(errorReport);
        }

        public ErrorReport remove(ErrorReport errorReport, bool cascade)
        {
          ErrorReportDataMapper dataMapper = new ErrorReportDataMapper(this);

          return dataMapper.remove(errorReport, cascade);
        }
    

        public Image create(Image image)
        {
          ImageDataMapper dataMapper = new ImageDataMapper(this);
          
          return dataMapper.create(image);
        }

        public Image update(Image image)
        {
          ImageDataMapper dataMapper = new ImageDataMapper(this);

          return dataMapper.update(image);
        }

        public Image remove(Image image, bool cascade)
        {
          ImageDataMapper dataMapper = new ImageDataMapper(this);

          return dataMapper.remove(image, cascade);
        }
    

        public Language create(Language language)
        {
          LanguageDataMapper dataMapper = new LanguageDataMapper(this);
          
          return dataMapper.create(language);
        }

        public Language update(Language language)
        {
          LanguageDataMapper dataMapper = new LanguageDataMapper(this);

          return dataMapper.update(language);
        }

        public Language remove(Language language, bool cascade)
        {
          LanguageDataMapper dataMapper = new LanguageDataMapper(this);

          return dataMapper.remove(language, cascade);
        }
    

        public Module create(Module module)
        {
          ModuleDataMapper dataMapper = new ModuleDataMapper(this);
          
          return dataMapper.create(module);
        }

        public Module update(Module module)
        {
          ModuleDataMapper dataMapper = new ModuleDataMapper(this);

          return dataMapper.update(module);
        }

        public Module remove(Module module, bool cascade)
        {
          ModuleDataMapper dataMapper = new ModuleDataMapper(this);

          return dataMapper.remove(module, cascade);
        }
    

        public Question create(Question question)
        {
          QuestionDataMapper dataMapper = new QuestionDataMapper(this);
          
          return dataMapper.create(question);
        }

        public Question update(Question question)
        {
          QuestionDataMapper dataMapper = new QuestionDataMapper(this);

          return dataMapper.update(question);
        }

        public Question remove(Question question, bool cascade)
        {
          QuestionDataMapper dataMapper = new QuestionDataMapper(this);

          return dataMapper.remove(question, cascade);
        }
    

        public QuestionHistory create(QuestionHistory questionHistory)
        {
          QuestionHistoryDataMapper dataMapper = new QuestionHistoryDataMapper(this);
          
          return dataMapper.create(questionHistory);
        }

        public QuestionHistory update(QuestionHistory questionHistory)
        {
          QuestionHistoryDataMapper dataMapper = new QuestionHistoryDataMapper(this);

          return dataMapper.update(questionHistory);
        }

        public QuestionHistory remove(QuestionHistory questionHistory, bool cascade)
        {
          QuestionHistoryDataMapper dataMapper = new QuestionHistoryDataMapper(this);

          return dataMapper.remove(questionHistory, cascade);
        }
    

        public QuestionType create(QuestionType questionType)
        {
          QuestionTypeDataMapper dataMapper = new QuestionTypeDataMapper(this);
          
          return dataMapper.create(questionType);
        }

        public QuestionType update(QuestionType questionType)
        {
          QuestionTypeDataMapper dataMapper = new QuestionTypeDataMapper(this);

          return dataMapper.update(questionType);
        }

        public QuestionType remove(QuestionType questionType, bool cascade)
        {
          QuestionTypeDataMapper dataMapper = new QuestionTypeDataMapper(this);

          return dataMapper.remove(questionType, cascade);
        }
    

        public Quiz create(Quiz quiz)
        {
          QuizDataMapper dataMapper = new QuizDataMapper(this);
          
          return dataMapper.create(quiz);
        }

        public Quiz update(Quiz quiz)
        {
          QuizDataMapper dataMapper = new QuizDataMapper(this);

          return dataMapper.update(quiz);
        }

        public Quiz remove(Quiz quiz, bool cascade)
        {
          QuizDataMapper dataMapper = new QuizDataMapper(this);

          return dataMapper.remove(quiz, cascade);
        }
    

        public QuizFormat create(QuizFormat quizFormat)
        {
          QuizFormatDataMapper dataMapper = new QuizFormatDataMapper(this);
          
          return dataMapper.create(quizFormat);
        }

        public QuizFormat update(QuizFormat quizFormat)
        {
          QuizFormatDataMapper dataMapper = new QuizFormatDataMapper(this);

          return dataMapper.update(quizFormat);
        }

        public QuizFormat remove(QuizFormat quizFormat, bool cascade)
        {
          QuizFormatDataMapper dataMapper = new QuizFormatDataMapper(this);

          return dataMapper.remove(quizFormat, cascade);
        }
    

        public QuizQuestionResult create(QuizQuestionResult quizQuestionResult)
        {
          QuizQuestionResultDataMapper dataMapper = new QuizQuestionResultDataMapper(this);
          
          return dataMapper.create(quizQuestionResult);
        }

        public QuizQuestionResult update(QuizQuestionResult quizQuestionResult)
        {
          QuizQuestionResultDataMapper dataMapper = new QuizQuestionResultDataMapper(this);

          return dataMapper.update(quizQuestionResult);
        }

        public QuizQuestionResult remove(QuizQuestionResult quizQuestionResult, bool cascade)
        {
          QuizQuestionResultDataMapper dataMapper = new QuizQuestionResultDataMapper(this);

          return dataMapper.remove(quizQuestionResult, cascade);
        }
    

        public QuizResult create(QuizResult quizResult)
        {
          QuizResultDataMapper dataMapper = new QuizResultDataMapper(this);
          
          return dataMapper.create(quizResult);
        }

        public QuizResult update(QuizResult quizResult)
        {
          QuizResultDataMapper dataMapper = new QuizResultDataMapper(this);

          return dataMapper.update(quizResult);
        }

        public QuizResult remove(QuizResult quizResult, bool cascade)
        {
          QuizResultDataMapper dataMapper = new QuizResultDataMapper(this);

          return dataMapper.remove(quizResult, cascade);
        }
    

        public ScoreType create(ScoreType scoreType)
        {
          ScoreTypeDataMapper dataMapper = new ScoreTypeDataMapper(this);
          
          return dataMapper.create(scoreType);
        }

        public ScoreType update(ScoreType scoreType)
        {
          ScoreTypeDataMapper dataMapper = new ScoreTypeDataMapper(this);

          return dataMapper.update(scoreType);
        }

        public ScoreType remove(ScoreType scoreType, bool cascade)
        {
          ScoreTypeDataMapper dataMapper = new ScoreTypeDataMapper(this);

          return dataMapper.remove(scoreType, cascade);
        }
    

        public ServerStatus create(ServerStatus serverStatus)
        {
          ServerStatusDataMapper dataMapper = new ServerStatusDataMapper(this);
          
          return dataMapper.create(serverStatus);
        }

        public ServerStatus update(ServerStatus serverStatus)
        {
          ServerStatusDataMapper dataMapper = new ServerStatusDataMapper(this);

          return dataMapper.update(serverStatus);
        }

        public ServerStatus remove(ServerStatus serverStatus, bool cascade)
        {
          ServerStatusDataMapper dataMapper = new ServerStatusDataMapper(this);

          return dataMapper.remove(serverStatus, cascade);
        }
    

        public SNProfile create(SNProfile sNProfile)
        {
          SNProfileDataMapper dataMapper = new SNProfileDataMapper(this);
          
          return dataMapper.create(sNProfile);
        }

        public SNProfile update(SNProfile sNProfile)
        {
          SNProfileDataMapper dataMapper = new SNProfileDataMapper(this);

          return dataMapper.update(sNProfile);
        }

        public SNProfile remove(SNProfile sNProfile, bool cascade)
        {
          SNProfileDataMapper dataMapper = new SNProfileDataMapper(this);

          return dataMapper.remove(sNProfile, cascade);
        }
    

        public SNProfileResult create(SNProfileResult sNProfileResult)
        {
          SNProfileResultDataMapper dataMapper = new SNProfileResultDataMapper(this);
          
          return dataMapper.create(sNProfileResult);
        }

        public SNProfileResult update(SNProfileResult sNProfileResult)
        {
          SNProfileResultDataMapper dataMapper = new SNProfileResultDataMapper(this);

          return dataMapper.update(sNProfileResult);
        }

        public SNProfileResult remove(SNProfileResult sNProfileResult, bool cascade)
        {
          SNProfileResultDataMapper dataMapper = new SNProfileResultDataMapper(this);

          return dataMapper.remove(sNProfileResult, cascade);
        }
    

        public SNProfileSNService create(SNProfileSNService sNProfileSNService)
        {
          SNProfileSNServiceDataMapper dataMapper = new SNProfileSNServiceDataMapper(this);
          
          return dataMapper.create(sNProfileSNService);
        }

        public SNProfileSNService update(SNProfileSNService sNProfileSNService)
        {
          SNProfileSNServiceDataMapper dataMapper = new SNProfileSNServiceDataMapper(this);

          return dataMapper.update(sNProfileSNService);
        }

        public SNProfileSNService remove(SNProfileSNService sNProfileSNService, bool cascade)
        {
          SNProfileSNServiceDataMapper dataMapper = new SNProfileSNServiceDataMapper(this);

          return dataMapper.remove(sNProfileSNService, cascade);
        }
    

        public SNService create(SNService sNService)
        {
          SNServiceDataMapper dataMapper = new SNServiceDataMapper(this);
          
          return dataMapper.create(sNService);
        }

        public SNService update(SNService sNService)
        {
          SNServiceDataMapper dataMapper = new SNServiceDataMapper(this);

          return dataMapper.update(sNService);
        }

        public SNService remove(SNService sNService, bool cascade)
        {
          SNServiceDataMapper dataMapper = new SNServiceDataMapper(this);

          return dataMapper.remove(sNService, cascade);
        }
    

        public State create(State state)
        {
          StateDataMapper dataMapper = new StateDataMapper(this);
          
          return dataMapper.create(state);
        }

        public State update(State state)
        {
          StateDataMapper dataMapper = new StateDataMapper(this);

          return dataMapper.update(state);
        }

        public State remove(State state, bool cascade)
        {
          StateDataMapper dataMapper = new StateDataMapper(this);

          return dataMapper.remove(state, cascade);
        }
    

        public SubModule create(SubModule subModule)
        {
          SubModuleDataMapper dataMapper = new SubModuleDataMapper(this);
          
          return dataMapper.create(subModule);
        }

        public SubModule update(SubModule subModule)
        {
          SubModuleDataMapper dataMapper = new SubModuleDataMapper(this);

          return dataMapper.update(subModule);
        }

        public SubModule remove(SubModule subModule, bool cascade)
        {
          SubModuleDataMapper dataMapper = new SubModuleDataMapper(this);

          return dataMapper.remove(subModule, cascade);
        }
    

        public SubModuleCategory create(SubModuleCategory subModuleCategory)
        {
          SubModuleCategoryDataMapper dataMapper = new SubModuleCategoryDataMapper(this);
          
          return dataMapper.create(subModuleCategory);
        }

        public SubModuleCategory update(SubModuleCategory subModuleCategory)
        {
          SubModuleCategoryDataMapper dataMapper = new SubModuleCategoryDataMapper(this);

          return dataMapper.update(subModuleCategory);
        }

        public SubModuleCategory remove(SubModuleCategory subModuleCategory, bool cascade)
        {
          SubModuleCategoryDataMapper dataMapper = new SubModuleCategoryDataMapper(this);

          return dataMapper.remove(subModuleCategory, cascade);
        }
    

        public SubModuleItem create(SubModuleItem subModuleItem)
        {
          SubModuleItemDataMapper dataMapper = new SubModuleItemDataMapper(this);
          
          return dataMapper.create(subModuleItem);
        }

        public SubModuleItem update(SubModuleItem subModuleItem)
        {
          SubModuleItemDataMapper dataMapper = new SubModuleItemDataMapper(this);

          return dataMapper.update(subModuleItem);
        }

        public SubModuleItem remove(SubModuleItem subModuleItem, bool cascade)
        {
          SubModuleItemDataMapper dataMapper = new SubModuleItemDataMapper(this);

          return dataMapper.remove(subModuleItem, cascade);
        }
    

        public Survey create(Survey survey)
        {
          SurveyDataMapper dataMapper = new SurveyDataMapper(this);
          
          return dataMapper.create(survey);
        }

        public Survey update(Survey survey)
        {
          SurveyDataMapper dataMapper = new SurveyDataMapper(this);

          return dataMapper.update(survey);
        }

        public Survey remove(Survey survey, bool cascade)
        {
          SurveyDataMapper dataMapper = new SurveyDataMapper(this);

          return dataMapper.remove(survey, cascade);
        }
    

        public SurveyDistractor create(SurveyDistractor surveyDistractor)
        {
          SurveyDistractorDataMapper dataMapper = new SurveyDistractorDataMapper(this);
          
          return dataMapper.create(surveyDistractor);
        }

        public SurveyDistractor update(SurveyDistractor surveyDistractor)
        {
          SurveyDistractorDataMapper dataMapper = new SurveyDistractorDataMapper(this);

          return dataMapper.update(surveyDistractor);
        }

        public SurveyDistractor remove(SurveyDistractor surveyDistractor, bool cascade)
        {
          SurveyDistractorDataMapper dataMapper = new SurveyDistractorDataMapper(this);

          return dataMapper.remove(surveyDistractor, cascade);
        }
    

        public SurveyDistractorHistory create(SurveyDistractorHistory surveyDistractorHistory)
        {
          SurveyDistractorHistoryDataMapper dataMapper = new SurveyDistractorHistoryDataMapper(this);
          
          return dataMapper.create(surveyDistractorHistory);
        }

        public SurveyDistractorHistory update(SurveyDistractorHistory surveyDistractorHistory)
        {
          SurveyDistractorHistoryDataMapper dataMapper = new SurveyDistractorHistoryDataMapper(this);

          return dataMapper.update(surveyDistractorHistory);
        }

        public SurveyDistractorHistory remove(SurveyDistractorHistory surveyDistractorHistory, bool cascade)
        {
          SurveyDistractorHistoryDataMapper dataMapper = new SurveyDistractorHistoryDataMapper(this);

          return dataMapper.remove(surveyDistractorHistory, cascade);
        }
    

        public SurveyQuestion create(SurveyQuestion surveyQuestion)
        {
          SurveyQuestionDataMapper dataMapper = new SurveyQuestionDataMapper(this);
          
          return dataMapper.create(surveyQuestion);
        }

        public SurveyQuestion update(SurveyQuestion surveyQuestion)
        {
          SurveyQuestionDataMapper dataMapper = new SurveyQuestionDataMapper(this);

          return dataMapper.update(surveyQuestion);
        }

        public SurveyQuestion remove(SurveyQuestion surveyQuestion, bool cascade)
        {
          SurveyQuestionDataMapper dataMapper = new SurveyQuestionDataMapper(this);

          return dataMapper.remove(surveyQuestion, cascade);
        }
    

        public SurveyQuestionHistory create(SurveyQuestionHistory surveyQuestionHistory)
        {
          SurveyQuestionHistoryDataMapper dataMapper = new SurveyQuestionHistoryDataMapper(this);
          
          return dataMapper.create(surveyQuestionHistory);
        }

        public SurveyQuestionHistory update(SurveyQuestionHistory surveyQuestionHistory)
        {
          SurveyQuestionHistoryDataMapper dataMapper = new SurveyQuestionHistoryDataMapper(this);

          return dataMapper.update(surveyQuestionHistory);
        }

        public SurveyQuestionHistory remove(SurveyQuestionHistory surveyQuestionHistory, bool cascade)
        {
          SurveyQuestionHistoryDataMapper dataMapper = new SurveyQuestionHistoryDataMapper(this);

          return dataMapper.remove(surveyQuestionHistory, cascade);
        }
    

        public SurveyQuestionType create(SurveyQuestionType surveyQuestionType)
        {
          SurveyQuestionTypeDataMapper dataMapper = new SurveyQuestionTypeDataMapper(this);
          
          return dataMapper.create(surveyQuestionType);
        }

        public SurveyQuestionType update(SurveyQuestionType surveyQuestionType)
        {
          SurveyQuestionTypeDataMapper dataMapper = new SurveyQuestionTypeDataMapper(this);

          return dataMapper.update(surveyQuestionType);
        }

        public SurveyQuestionType remove(SurveyQuestionType surveyQuestionType, bool cascade)
        {
          SurveyQuestionTypeDataMapper dataMapper = new SurveyQuestionTypeDataMapper(this);

          return dataMapper.remove(surveyQuestionType, cascade);
        }
    

        public SurveyResult create(SurveyResult surveyResult)
        {
          SurveyResultDataMapper dataMapper = new SurveyResultDataMapper(this);
          
          return dataMapper.create(surveyResult);
        }

        public SurveyResult update(SurveyResult surveyResult)
        {
          SurveyResultDataMapper dataMapper = new SurveyResultDataMapper(this);

          return dataMapper.update(surveyResult);
        }

        public SurveyResult remove(SurveyResult surveyResult, bool cascade)
        {
          SurveyResultDataMapper dataMapper = new SurveyResultDataMapper(this);

          return dataMapper.remove(surveyResult, cascade);
        }
    

        public Test create(Test test)
        {
          TestDataMapper dataMapper = new TestDataMapper(this);
          
          return dataMapper.create(test);
        }

        public Test update(Test test)
        {
          TestDataMapper dataMapper = new TestDataMapper(this);

          return dataMapper.update(test);
        }

        public Test remove(Test test, bool cascade)
        {
          TestDataMapper dataMapper = new TestDataMapper(this);

          return dataMapper.remove(test, cascade);
        }
    

        public TestResult create(TestResult testResult)
        {
          TestResultDataMapper dataMapper = new TestResultDataMapper(this);
          
          return dataMapper.create(testResult);
        }

        public TestResult update(TestResult testResult)
        {
          TestResultDataMapper dataMapper = new TestResultDataMapper(this);

          return dataMapper.update(testResult);
        }

        public TestResult remove(TestResult testResult, bool cascade)
        {
          TestResultDataMapper dataMapper = new TestResultDataMapper(this);

          return dataMapper.remove(testResult, cascade);
        }
    

        public Theme create(Theme theme)
        {
          ThemeDataMapper dataMapper = new ThemeDataMapper(this);
          
          return dataMapper.create(theme);
        }

        public Theme update(Theme theme)
        {
          ThemeDataMapper dataMapper = new ThemeDataMapper(this);

          return dataMapper.update(theme);
        }

        public Theme remove(Theme theme, bool cascade)
        {
          ThemeDataMapper dataMapper = new ThemeDataMapper(this);

          return dataMapper.remove(theme, cascade);
        }
    

        public ThemeAttribute create(ThemeAttribute themeAttribute)
        {
          ThemeAttributeDataMapper dataMapper = new ThemeAttributeDataMapper(this);
          
          return dataMapper.create(themeAttribute);
        }

        public ThemeAttribute update(ThemeAttribute themeAttribute)
        {
          ThemeAttributeDataMapper dataMapper = new ThemeAttributeDataMapper(this);

          return dataMapper.update(themeAttribute);
        }

        public ThemeAttribute remove(ThemeAttribute themeAttribute, bool cascade)
        {
          ThemeAttributeDataMapper dataMapper = new ThemeAttributeDataMapper(this);

          return dataMapper.remove(themeAttribute, cascade);
        }
    

        public TimeZone create(TimeZone timeZone)
        {
          TimeZoneDataMapper dataMapper = new TimeZoneDataMapper(this);
          
          return dataMapper.create(timeZone);
        }

        public TimeZone update(TimeZone timeZone)
        {
          TimeZoneDataMapper dataMapper = new TimeZoneDataMapper(this);

          return dataMapper.update(timeZone);
        }

        public TimeZone remove(TimeZone timeZone, bool cascade)
        {
          TimeZoneDataMapper dataMapper = new TimeZoneDataMapper(this);

          return dataMapper.remove(timeZone, cascade);
        }
    

        public User create(User user)
        {
          UserDataMapper dataMapper = new UserDataMapper(this);
          
          return dataMapper.create(user);
        }

        public User update(User user)
        {
          UserDataMapper dataMapper = new UserDataMapper(this);

          return dataMapper.update(user);
        }

        public User remove(User user, bool cascade)
        {
          UserDataMapper dataMapper = new UserDataMapper(this);

          return dataMapper.remove(user, cascade);
        }
    

        public UserActivation create(UserActivation userActivation)
        {
          UserActivationDataMapper dataMapper = new UserActivationDataMapper(this);
          
          return dataMapper.create(userActivation);
        }

        public UserActivation update(UserActivation userActivation)
        {
          UserActivationDataMapper dataMapper = new UserActivationDataMapper(this);

          return dataMapper.update(userActivation);
        }

        public UserActivation remove(UserActivation userActivation, bool cascade)
        {
          UserActivationDataMapper dataMapper = new UserActivationDataMapper(this);

          return dataMapper.remove(userActivation, cascade);
        }
    

        public UserLoginHistory create(UserLoginHistory userLoginHistory)
        {
          UserLoginHistoryDataMapper dataMapper = new UserLoginHistoryDataMapper(this);
          
          return dataMapper.create(userLoginHistory);
        }

        public UserLoginHistory update(UserLoginHistory userLoginHistory)
        {
          UserLoginHistoryDataMapper dataMapper = new UserLoginHistoryDataMapper(this);

          return dataMapper.update(userLoginHistory);
        }

        public UserLoginHistory remove(UserLoginHistory userLoginHistory, bool cascade)
        {
          UserLoginHistoryDataMapper dataMapper = new UserLoginHistoryDataMapper(this);

          return dataMapper.remove(userLoginHistory, cascade);
        }
    

        public UserRole create(UserRole userRole)
        {
          UserRoleDataMapper dataMapper = new UserRoleDataMapper(this);
          
          return dataMapper.create(userRole);
        }

        public UserRole update(UserRole userRole)
        {
          UserRoleDataMapper dataMapper = new UserRoleDataMapper(this);

          return dataMapper.update(userRole);
        }

        public UserRole remove(UserRole userRole, bool cascade)
        {
          UserRoleDataMapper dataMapper = new UserRoleDataMapper(this);

          return dataMapper.remove(userRole, cascade);
        }
    
        public DataSet GetAppletCategoriesByUserID(
        int 
            UserId)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getAppletCategoriesByUserID]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@userId", 
                        UserId);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetAppletSubModuleItemsByUserID(
        int 
            UserId)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getAppletSubModuleItemsByUserID]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@userId", 
                        UserId);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetBaseQuizInfoByQuizId(
        int 
            QuizID)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getBaseQuizInfoByQuizId]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@quizID", 
                        QuizID);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetCrosswordReportDataByUserIdAndSessionID(
        int 
            UserId,int 
            Sessionid)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getCrosswordReportDataByUserIdAndSessionID]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@userId", 
                        UserId);
                    
                      sqlCommand.Parameters.AddWithValue("@sessionid", 
                        Sessionid);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetCrosswordResultByACSessionId(
        int 
            AcSessionId)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getCrosswordResultByACSessionId]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@acSessionId", 
                        AcSessionId);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetCrosswordSessionsByUserId(
        int 
            UserId)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getCrosswordSessionsByUserId]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@userId", 
                        UserId);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetQuizCategoriesByUserID(
        int 
            UserId)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getQuizCategoriesByUserID]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@userId", 
                        UserId);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetQuizDistractorsBySMIId(
        int 
            SubModuleItemId)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getQuizDistractorsBySMIId]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@subModuleItemId", 
                        SubModuleItemId);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetQuizQuestionsBySMIId(
        int 
            SubModuleItemId)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getQuizQuestionsBySMIId]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@subModuleItemId", 
                        SubModuleItemId);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetQuizQuestionsForAdminBySMIId(
        int 
            SubModuleItemId,int 
            AcSessionID)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getQuizQuestionsForAdminBySMIId]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@subModuleItemId", 
                        SubModuleItemId);
                    
                      sqlCommand.Parameters.AddWithValue("@acSessionID", 
                        AcSessionID);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetQuizResultByACSessionId(
        int 
            AcSessionId,int 
            SubModuleItemID)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getQuizResultByACSessionId]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@acSessionId", 
                        AcSessionId);
                    
                      sqlCommand.Parameters.AddWithValue("@subModuleItemID", 
                        SubModuleItemID);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetQuizSessionsByUserId(
        int 
            UserId)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getQuizSessionsByUserId]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@userId", 
                        UserId);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetQuizSubModuleItemsByUserID(
        int 
            UserId)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getQuizSubModuleItemsByUserID]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@userId", 
                        UserId);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetSharedForUserCrosswordsByUserId(
        int 
            UserId)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getSharedForUserCrosswordsByUserId]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@userId", 
                        UserId);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetSharedForUserQuizzesByUserId(
        int 
            UserId)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getSharedForUserQuizzesByUserId]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@userId", 
                        UserId);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetSNProfileCategoriesByUserID(
        int 
            UserId)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getSNProfileCategoriesByUserID]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@userId", 
                        UserId);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetSNProfileSubModuleItemsByUserID(
        int 
            UserId)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getSNProfileSubModuleItemsByUserID]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@userId", 
                        UserId);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetSurveyCategoriesByUserID(
        int 
            UserId)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getSurveyCategoriesByUserID]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@userId", 
                        UserId);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetSurveySubModuleItemsByUserID(
        int 
            UserId)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getSurveySubModuleItemsByUserID]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@userId", 
                        UserId);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetTestCategoriesByUserID(
        int 
            UserId)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getTestCategoriesByUserID]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@userId", 
                        UserId);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetTestSubModuleItemsByUserID(
        int 
            UserId)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getTestSubModuleItemsByUserID]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@userId", 
                        UserId);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetUsersCrosswordsByUserId(
        int 
            UserId)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getUsersCrosswordsByUserId]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@userId", 
                        UserId);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet GetUsersQuizzesByUserId(
        int 
            UserId)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[getUsersQuizzesByUserId]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@userId", 
                        UserId);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet Sp_alterdiagram(
        String 
            Diagramname,int 
            Owner_id,int 
            Version,byte[] 
            Definition)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[sp_alterdiagram]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@diagramname", 
                        Diagramname);
                    
                      sqlCommand.Parameters.AddWithValue("@owner_id", 
                        Owner_id);
                    
                      sqlCommand.Parameters.AddWithValue("@version", 
                        Version);
                    
                      sqlCommand.Parameters.AddWithValue("@definition", 
                        Definition);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet Sp_creatediagram(
        String 
            Diagramname,int 
            Owner_id,int 
            Version,byte[] 
            Definition)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[sp_creatediagram]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@diagramname", 
                        Diagramname);
                    
                      sqlCommand.Parameters.AddWithValue("@owner_id", 
                        Owner_id);
                    
                      sqlCommand.Parameters.AddWithValue("@version", 
                        Version);
                    
                      sqlCommand.Parameters.AddWithValue("@definition", 
                        Definition);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet Sp_dropdiagram(
        String 
            Diagramname,int 
            Owner_id)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[sp_dropdiagram]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@diagramname", 
                        Diagramname);
                    
                      sqlCommand.Parameters.AddWithValue("@owner_id", 
                        Owner_id);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet Sp_helpdiagramdefinition(
        String 
            Diagramname,int 
            Owner_id)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[sp_helpdiagramdefinition]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@diagramname", 
                        Diagramname);
                    
                      sqlCommand.Parameters.AddWithValue("@owner_id", 
                        Owner_id);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet Sp_helpdiagrams(
        String 
            Diagramname,int 
            Owner_id)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[sp_helpdiagrams]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@diagramname", 
                        Diagramname);
                    
                      sqlCommand.Parameters.AddWithValue("@owner_id", 
                        Owner_id);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet Sp_renamediagram(
        String 
            Diagramname,int 
            Owner_id,String 
            New_diagramname)
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[sp_renamediagram]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
                      sqlCommand.Parameters.AddWithValue("@diagramname", 
                        Diagramname);
                    
                      sqlCommand.Parameters.AddWithValue("@owner_id", 
                        Owner_id);
                    
                      sqlCommand.Parameters.AddWithValue("@new_diagramname", 
                        New_diagramname);
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
        public DataSet Sp_upgraddiagrams(
        )
        {
        DataSet dataSet = new DataSet();

        using (DatabaseConnectionMonitor databaseConnectionMonitor = new DatabaseConnectionMonitor(this))
        {
        using (SqlCommand sqlCommand = CreateCommand( "[dbo].[sp_upgraddiagrams]" ))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    
        
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    
                    sqlDataAdapter.Fill(dataSet);
                }
            }

            return dataSet;
        }
      
    }
  
          }
        