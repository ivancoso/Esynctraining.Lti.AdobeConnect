
        namespace EdugameCloud
        {
        public class SurveyQuestionHistoryDataMapper :_SurveyQuestionHistoryDataMapper
        {
        public SurveyQuestionHistoryDataMapper()
        {}
        public SurveyQuestionHistoryDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      