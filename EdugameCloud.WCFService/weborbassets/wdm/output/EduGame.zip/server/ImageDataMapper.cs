
        namespace EdugameCloud
        {
        public class ImageDataMapper :_ImageDataMapper
        {
        public ImageDataMapper()
        {}
        public ImageDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      