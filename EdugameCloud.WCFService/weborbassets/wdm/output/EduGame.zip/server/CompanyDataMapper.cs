
        namespace EdugameCloud
        {
        public class CompanyDataMapper :_CompanyDataMapper
        {
        public CompanyDataMapper()
        {}
        public CompanyDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      