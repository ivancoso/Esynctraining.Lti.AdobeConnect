
        namespace EdugameCloud
        {
        public partial class Quiz
        {

        }
        }
      