
        namespace EdugameCloud
        {
        public class QuizDataMapper :_QuizDataMapper
        {
        public QuizDataMapper()
        {}
        public QuizDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      