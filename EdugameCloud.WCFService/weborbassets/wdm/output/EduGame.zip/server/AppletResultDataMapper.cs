
        namespace EdugameCloud
        {
        public class AppletResultDataMapper :_AppletResultDataMapper
        {
        public AppletResultDataMapper()
        {}
        public AppletResultDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      