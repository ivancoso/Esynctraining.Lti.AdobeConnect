
        namespace EdugameCloud
        {
        public class ErrorReportDataMapper :_ErrorReportDataMapper
        {
        public ErrorReportDataMapper()
        {}
        public ErrorReportDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      