
        namespace EdugameCloud
        {
        public class QuestionDataMapper :_QuestionDataMapper
        {
        public QuestionDataMapper()
        {}
        public QuestionDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      