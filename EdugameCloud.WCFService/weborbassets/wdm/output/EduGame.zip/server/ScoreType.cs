
        namespace EdugameCloud
        {
        public partial class ScoreType
        {

        }
        }
      