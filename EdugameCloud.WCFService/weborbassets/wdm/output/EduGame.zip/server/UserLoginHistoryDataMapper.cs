
        namespace EdugameCloud
        {
        public class UserLoginHistoryDataMapper :_UserLoginHistoryDataMapper
        {
        public UserLoginHistoryDataMapper()
        {}
        public UserLoginHistoryDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      