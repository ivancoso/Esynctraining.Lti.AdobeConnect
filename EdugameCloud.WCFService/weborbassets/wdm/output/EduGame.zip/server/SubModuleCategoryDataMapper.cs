
        namespace EdugameCloud
        {
        public class SubModuleCategoryDataMapper :_SubModuleCategoryDataMapper
        {
        public SubModuleCategoryDataMapper()
        {}
        public SubModuleCategoryDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      