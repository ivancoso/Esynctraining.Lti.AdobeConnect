
        namespace EdugameCloud
        {
        public class CountryDataMapper :_CountryDataMapper
        {
        public CountryDataMapper()
        {}
        public CountryDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      