
        namespace EdugameCloud
        {
        public partial class QuizQuestionResult
        {

        }
        }
      