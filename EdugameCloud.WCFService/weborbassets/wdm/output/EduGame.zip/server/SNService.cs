
        namespace EdugameCloud
        {
        public partial class SNService
        {

        }
        }
      