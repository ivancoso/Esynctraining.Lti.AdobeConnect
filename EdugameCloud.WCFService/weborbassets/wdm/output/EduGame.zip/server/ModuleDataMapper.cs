
        namespace EdugameCloud
        {
        public class ModuleDataMapper :_ModuleDataMapper
        {
        public ModuleDataMapper()
        {}
        public ModuleDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      