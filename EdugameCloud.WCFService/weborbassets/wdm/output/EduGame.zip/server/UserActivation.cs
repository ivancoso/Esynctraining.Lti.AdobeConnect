
        namespace EdugameCloud
        {
        public partial class UserActivation
        {

        }
        }
      