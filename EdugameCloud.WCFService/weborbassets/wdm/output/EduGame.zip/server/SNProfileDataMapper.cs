
        namespace EdugameCloud
        {
        public class SNProfileDataMapper :_SNProfileDataMapper
        {
        public SNProfileDataMapper()
        {}
        public SNProfileDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      