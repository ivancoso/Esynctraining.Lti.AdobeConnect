
        namespace EdugameCloud
        {
        public class TestDataMapper :_TestDataMapper
        {
        public TestDataMapper()
        {}
        public TestDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      