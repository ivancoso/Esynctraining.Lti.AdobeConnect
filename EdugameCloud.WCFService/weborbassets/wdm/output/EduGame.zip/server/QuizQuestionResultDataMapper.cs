
        namespace EdugameCloud
        {
        public class QuizQuestionResultDataMapper :_QuizQuestionResultDataMapper
        {
        public QuizQuestionResultDataMapper()
        {}
        public QuizQuestionResultDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      