
        namespace EdugameCloud
        {
        public partial class SNProfileResult
        {

        }
        }
      