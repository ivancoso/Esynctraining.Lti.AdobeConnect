
        namespace EdugameCloud
        {
        public partial class ErrorReport
        {

        }
        }
      