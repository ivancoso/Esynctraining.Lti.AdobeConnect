
        namespace EdugameCloud
        {
        public partial class ACSession
        {

        }
        }
      