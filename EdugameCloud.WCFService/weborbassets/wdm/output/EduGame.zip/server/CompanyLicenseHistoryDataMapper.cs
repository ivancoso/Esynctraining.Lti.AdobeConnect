
        namespace EdugameCloud
        {
        public class CompanyLicenseHistoryDataMapper :_CompanyLicenseHistoryDataMapper
        {
        public CompanyLicenseHistoryDataMapper()
        {}
        public CompanyLicenseHistoryDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      