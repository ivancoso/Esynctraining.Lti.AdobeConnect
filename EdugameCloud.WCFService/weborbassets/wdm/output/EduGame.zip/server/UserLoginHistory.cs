
        namespace EdugameCloud
        {
        public partial class UserLoginHistory
        {

        }
        }
      