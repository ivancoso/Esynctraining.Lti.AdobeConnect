
        namespace EdugameCloud
        {
        public class DistractorHistoryDataMapper :_DistractorHistoryDataMapper
        {
        public DistractorHistoryDataMapper()
        {}
        public DistractorHistoryDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      