
        namespace EdugameCloud
        {
        public class ApplicationVersionDataMapper :_ApplicationVersionDataMapper
        {
        public ApplicationVersionDataMapper()
        {}
        public ApplicationVersionDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      