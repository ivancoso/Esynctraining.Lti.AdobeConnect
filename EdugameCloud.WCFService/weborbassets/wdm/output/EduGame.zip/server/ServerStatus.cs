
        namespace EdugameCloud
        {
        public partial class ServerStatus
        {

        }
        }
      