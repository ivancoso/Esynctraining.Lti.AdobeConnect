
        namespace EdugameCloud
        {
        public partial class CompanyLicense
        {

        }
        }
      