
        namespace EdugameCloud
        {
        public partial class Language
        {

        }
        }
      