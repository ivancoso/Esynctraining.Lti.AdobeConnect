
        namespace EdugameCloud
        {
        public class CompanyThemeDataMapper :_CompanyThemeDataMapper
        {
        public CompanyThemeDataMapper()
        {}
        public CompanyThemeDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      