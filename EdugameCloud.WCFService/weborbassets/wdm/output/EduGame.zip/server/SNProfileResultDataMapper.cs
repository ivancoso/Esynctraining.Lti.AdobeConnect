
        namespace EdugameCloud
        {
        public class SNProfileResultDataMapper :_SNProfileResultDataMapper
        {
        public SNProfileResultDataMapper()
        {}
        public SNProfileResultDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      