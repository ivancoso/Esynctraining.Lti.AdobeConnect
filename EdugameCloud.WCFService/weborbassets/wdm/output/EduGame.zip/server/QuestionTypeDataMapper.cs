
        namespace EdugameCloud
        {
        public class QuestionTypeDataMapper :_QuestionTypeDataMapper
        {
        public QuestionTypeDataMapper()
        {}
        public QuestionTypeDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      