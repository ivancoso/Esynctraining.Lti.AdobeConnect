
        namespace EdugameCloud
        {
        public partial class SNProfileSNService
        {

        }
        }
      