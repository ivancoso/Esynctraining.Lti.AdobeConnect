
        namespace EdugameCloud
        {
        public class SurveyDataMapper :_SurveyDataMapper
        {
        public SurveyDataMapper()
        {}
        public SurveyDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      