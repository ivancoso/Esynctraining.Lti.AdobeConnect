
        namespace EdugameCloud
        {
        public partial class SurveyQuestionType
        {

        }
        }
      