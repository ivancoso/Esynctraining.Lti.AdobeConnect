
        namespace EdugameCloud
        {
        public class ThemeAttributeDataMapper :_ThemeAttributeDataMapper
        {
        public ThemeAttributeDataMapper()
        {}
        public ThemeAttributeDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      