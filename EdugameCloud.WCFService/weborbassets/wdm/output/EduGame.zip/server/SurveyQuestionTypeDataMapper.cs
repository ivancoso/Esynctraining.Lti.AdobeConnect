
        namespace EdugameCloud
        {
        public class SurveyQuestionTypeDataMapper :_SurveyQuestionTypeDataMapper
        {
        public SurveyQuestionTypeDataMapper()
        {}
        public SurveyQuestionTypeDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      