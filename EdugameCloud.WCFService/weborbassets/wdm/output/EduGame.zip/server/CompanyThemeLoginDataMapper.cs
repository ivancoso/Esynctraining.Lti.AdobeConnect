
        namespace EdugameCloud
        {
        public class CompanyThemeLoginDataMapper :_CompanyThemeLoginDataMapper
        {
        public CompanyThemeLoginDataMapper()
        {}
        public CompanyThemeLoginDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      