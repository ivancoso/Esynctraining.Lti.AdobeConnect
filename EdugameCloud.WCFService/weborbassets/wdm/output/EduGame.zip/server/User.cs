
        namespace EdugameCloud
        {
        public partial class User
        {

        }
        }
      