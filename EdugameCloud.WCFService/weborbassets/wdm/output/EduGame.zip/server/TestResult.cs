
        namespace EdugameCloud
        {
        public partial class TestResult
        {

        }
        }
      