
        namespace EdugameCloud
        {
        public class ThemeDataMapper :_ThemeDataMapper
        {
        public ThemeDataMapper()
        {}
        public ThemeDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      