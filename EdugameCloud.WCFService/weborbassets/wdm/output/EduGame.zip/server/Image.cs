
        namespace EdugameCloud
        {
        public partial class Image
        {

        }
        }
      