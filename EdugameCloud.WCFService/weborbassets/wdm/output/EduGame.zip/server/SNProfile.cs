
        namespace EdugameCloud
        {
        public partial class SNProfile
        {

        }
        }
      