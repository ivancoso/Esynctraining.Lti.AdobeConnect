
        namespace EdugameCloud
        {
        public class SubModuleDataMapper :_SubModuleDataMapper
        {
        public SubModuleDataMapper()
        {}
        public SubModuleDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      