
        namespace EdugameCloud
        {
        public partial class QuizFormat
        {

        }
        }
      