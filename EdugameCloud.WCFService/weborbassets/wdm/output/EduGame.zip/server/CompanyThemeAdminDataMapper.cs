
        namespace EdugameCloud
        {
        public class CompanyThemeAdminDataMapper :_CompanyThemeAdminDataMapper
        {
        public CompanyThemeAdminDataMapper()
        {}
        public CompanyThemeAdminDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      