
        namespace EdugameCloud
        {
        public class CompanyThemeMeetingDataMapper :_CompanyThemeMeetingDataMapper
        {
        public CompanyThemeMeetingDataMapper()
        {}
        public CompanyThemeMeetingDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      