
        namespace EdugameCloud
        {
        public class AddressDataMapper :_AddressDataMapper
        {
        public AddressDataMapper()
        {}
        public AddressDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      