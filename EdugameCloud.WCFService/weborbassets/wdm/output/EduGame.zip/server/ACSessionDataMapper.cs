
        namespace EdugameCloud
        {
        public class ACSessionDataMapper :_ACSessionDataMapper
        {
        public ACSessionDataMapper()
        {}
        public ACSessionDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      