
        namespace EdugameCloud
        {
        public class UserActivationDataMapper :_UserActivationDataMapper
        {
        public UserActivationDataMapper()
        {}
        public UserActivationDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      