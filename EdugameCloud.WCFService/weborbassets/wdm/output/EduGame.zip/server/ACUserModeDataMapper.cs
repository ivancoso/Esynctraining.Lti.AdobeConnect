
        namespace EdugameCloud
        {
        public class ACUserModeDataMapper :_ACUserModeDataMapper
        {
        public ACUserModeDataMapper()
        {}
        public ACUserModeDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      