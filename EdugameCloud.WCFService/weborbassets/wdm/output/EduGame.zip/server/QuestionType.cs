
        namespace EdugameCloud
        {
        public partial class QuestionType
        {

        }
        }
      