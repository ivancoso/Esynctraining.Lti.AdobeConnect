
        namespace EdugameCloud
        {
        public partial class Address
        {

        }
        }
      