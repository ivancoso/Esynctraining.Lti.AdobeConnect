
        namespace EdugameCloud
        {
        public class SubModuleItemDataMapper :_SubModuleItemDataMapper
        {
        public SubModuleItemDataMapper()
        {}
        public SubModuleItemDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      