
        namespace EdugameCloud
        {
        public class QuizFormatDataMapper :_QuizFormatDataMapper
        {
        public QuizFormatDataMapper()
        {}
        public QuizFormatDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      