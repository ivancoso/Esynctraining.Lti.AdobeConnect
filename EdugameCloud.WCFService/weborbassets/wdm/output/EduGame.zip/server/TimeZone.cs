
        namespace EdugameCloud
        {
        public partial class TimeZone
        {

        }
        }
      