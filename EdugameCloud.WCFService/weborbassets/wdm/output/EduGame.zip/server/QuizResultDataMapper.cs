
        namespace EdugameCloud
        {
        public class QuizResultDataMapper :_QuizResultDataMapper
        {
        public QuizResultDataMapper()
        {}
        public QuizResultDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      