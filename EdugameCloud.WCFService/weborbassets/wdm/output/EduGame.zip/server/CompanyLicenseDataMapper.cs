
        namespace EdugameCloud
        {
        public class CompanyLicenseDataMapper :_CompanyLicenseDataMapper
        {
        public CompanyLicenseDataMapper()
        {}
        public CompanyLicenseDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      