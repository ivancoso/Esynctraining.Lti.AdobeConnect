
        namespace EdugameCloud
        {
        public class SurveyDistractorHistoryDataMapper :_SurveyDistractorHistoryDataMapper
        {
        public SurveyDistractorHistoryDataMapper()
        {}
        public SurveyDistractorHistoryDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      