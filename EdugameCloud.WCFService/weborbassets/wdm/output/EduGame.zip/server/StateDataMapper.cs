
        namespace EdugameCloud
        {
        public class StateDataMapper :_StateDataMapper
        {
        public StateDataMapper()
        {}
        public StateDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      