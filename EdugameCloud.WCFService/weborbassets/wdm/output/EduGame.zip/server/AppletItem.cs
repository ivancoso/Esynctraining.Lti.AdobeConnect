
        namespace EdugameCloud
        {
        public partial class AppletItem
        {

        }
        }
      