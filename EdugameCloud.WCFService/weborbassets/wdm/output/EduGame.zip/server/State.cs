
        namespace EdugameCloud
        {
        public partial class State
        {

        }
        }
      