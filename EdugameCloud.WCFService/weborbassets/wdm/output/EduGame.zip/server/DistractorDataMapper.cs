
        namespace EdugameCloud
        {
        public class DistractorDataMapper :_DistractorDataMapper
        {
        public DistractorDataMapper()
        {}
        public DistractorDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      