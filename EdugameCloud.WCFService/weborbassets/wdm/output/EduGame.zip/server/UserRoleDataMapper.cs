
        namespace EdugameCloud
        {
        public class UserRoleDataMapper :_UserRoleDataMapper
        {
        public UserRoleDataMapper()
        {}
        public UserRoleDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      