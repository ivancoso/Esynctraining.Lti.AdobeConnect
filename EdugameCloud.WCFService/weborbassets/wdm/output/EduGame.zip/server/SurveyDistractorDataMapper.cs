
        namespace EdugameCloud
        {
        public class SurveyDistractorDataMapper :_SurveyDistractorDataMapper
        {
        public SurveyDistractorDataMapper()
        {}
        public SurveyDistractorDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      