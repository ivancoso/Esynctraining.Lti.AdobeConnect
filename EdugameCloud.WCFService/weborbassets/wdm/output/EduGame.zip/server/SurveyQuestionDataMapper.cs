
        namespace EdugameCloud
        {
        public class SurveyQuestionDataMapper :_SurveyQuestionDataMapper
        {
        public SurveyQuestionDataMapper()
        {}
        public SurveyQuestionDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      