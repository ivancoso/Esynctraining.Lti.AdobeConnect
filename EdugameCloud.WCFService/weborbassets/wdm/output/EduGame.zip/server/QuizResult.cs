
        namespace EdugameCloud
        {
        public partial class QuizResult
        {

        }
        }
      