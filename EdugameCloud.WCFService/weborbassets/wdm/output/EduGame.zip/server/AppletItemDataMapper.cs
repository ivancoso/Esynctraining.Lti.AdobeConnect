
        namespace EdugameCloud
        {
        public class AppletItemDataMapper :_AppletItemDataMapper
        {
        public AppletItemDataMapper()
        {}
        public AppletItemDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      