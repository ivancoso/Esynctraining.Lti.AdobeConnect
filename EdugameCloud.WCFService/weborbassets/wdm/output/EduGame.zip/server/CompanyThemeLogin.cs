
        namespace EdugameCloud
        {
        public partial class CompanyThemeLogin
        {

        }
        }
      