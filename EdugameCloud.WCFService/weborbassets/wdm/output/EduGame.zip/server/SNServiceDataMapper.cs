
        namespace EdugameCloud
        {
        public class SNServiceDataMapper :_SNServiceDataMapper
        {
        public SNServiceDataMapper()
        {}
        public SNServiceDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      