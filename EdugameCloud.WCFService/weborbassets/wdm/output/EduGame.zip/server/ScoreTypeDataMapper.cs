
        namespace EdugameCloud
        {
        public class ScoreTypeDataMapper :_ScoreTypeDataMapper
        {
        public ScoreTypeDataMapper()
        {}
        public ScoreTypeDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      