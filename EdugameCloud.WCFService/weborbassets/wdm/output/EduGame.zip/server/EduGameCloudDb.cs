
          namespace EdugameCloud
          {
          public partial class EduGameCloudDb
          {

          }
          }
        