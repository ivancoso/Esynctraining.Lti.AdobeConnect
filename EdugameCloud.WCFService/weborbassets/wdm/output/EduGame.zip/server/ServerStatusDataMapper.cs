
        namespace EdugameCloud
        {
        public class ServerStatusDataMapper :_ServerStatusDataMapper
        {
        public ServerStatusDataMapper()
        {}
        public ServerStatusDataMapper(EduGameCloudDb database):base(database)
        {}
        }
        }
      